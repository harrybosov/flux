-- Тарифы по ТЗ (редактируются в админ-панели). Цены в Stars НЕ заданы — их выставляет админ.
INSERT INTO plans (id, name, days, price_rub, is_active, sort_order, created_at, updated_at) VALUES
    ('test', 'Тест',    7,   30,  1, 10, strftime('%s','now'), strftime('%s','now')),
    ('m1',   '1 месяц', 30,  100, 1, 20, strftime('%s','now'), strftime('%s','now')),
    ('m3',   '3 месяца', 90, 270, 1, 30, strftime('%s','now'), strftime('%s','now')),
    ('m6',   '6 месяцев', 180, 490, 1, 40, strftime('%s','now'), strftime('%s','now')),
    ('y1',   '1 год',   365, 890, 1, 50, strftime('%s','now'), strftime('%s','now'));
