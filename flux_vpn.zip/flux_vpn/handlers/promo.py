from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from keyboards import btn, home, kb
from services.promo import PromoError
from utils import texts
from utils.ui import render

router = Router(name="promo")


class PromoStates(StatesGroup):
    waiting = State()


@router.callback_query(F.data == "promo")
async def promo(cb: CallbackQuery, state: FSMContext):
    await state.set_state(PromoStates.waiting)
    await render(cb, "🎟 <b>Промокод</b>\n\nОтправьте промокод одним сообщением.",
                 kb([[btn("🔙 Отмена", "menu", style="danger")]]))


@router.message(PromoStates.waiting, F.text)
async def promo_code(msg: Message, state: FSMContext, svc, user):
    try:
        promo, sub = await svc.promo.redeem(user["id"], msg.text)
    except PromoError as e:
        return await msg.answer(f"❌ {e}\n\nПопробуйте другой код или вернитесь в меню.",
                                reply_markup=kb([[btn("🔙 Отмена", "menu", style="danger")]]))
    await state.clear()
    await svc.fulfillment.finish_grant(user["id"])
    await msg.answer(texts.n_promo(promo["bonus_days"], texts.fmt_dt(sub["ends_at"], svc.settings.timezone)),
                     reply_markup=kb([[btn("🔑 Мои подключения", "conns", style="success")], [home()]]))
