from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from keyboards import main_menu

router = Router(name="start")

MAIN_TEXT = ("⚡ <b>FLUX VPN</b>\n\nБыстрый и защищённый VPN.\n"
             "После оплаты вы получаете сразу 6 подключений: 🇩🇪 Германия ×3 и 🇺🇸 США ×3.\n\n"
             "Выберите действие:")


@router.message(CommandStart())
async def start(msg: Message, state: FSMContext, is_new: bool, is_admin: bool):
    await state.clear()
    text = MAIN_TEXT
    if is_new:
        text = "👋 Добро пожаловать!\n\n" + text
    await msg.answer(text, reply_markup=main_menu(is_admin))


@router.message(Command("menu"))
async def menu_cmd(msg: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await msg.answer(MAIN_TEXT, reply_markup=main_menu(is_admin))
