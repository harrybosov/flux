import logging

from aiogram import F, Router
from aiogram.types import BufferedInputFile, CallbackQuery

from keyboards import btn, conn_kb, conns_kb, home, kb
from utils import texts
from utils.qr import make_qr_png
from utils.ui import alert, render
from vpn.nodes import country_meta

log = logging.getLogger(__name__)
router = Router(name="connections")
E = texts.E

HELP = ("📖 <b>Как подключиться</b>\n\n"
        "1. Установите VPN-клиент с поддержкой VLESS (например v2rayNG, Hiddify, Streisand, Happ).\n"
        "2. Откройте «🔑 Мои подключения» и выберите подключение.\n"
        "3. Скопируйте ссылку (кнопка «Копировать») или отсканируйте QR-код.\n"
        "4. В приложении выберите «Импорт из буфера обмена» / «Сканировать QR» и включите VPN.\n\n"
        "Подписка даёт 6 подключений — если одно работает хуже, переключитесь на другую страну или номер.\n"
        "Не делитесь ссылками: они привязаны к вашей подписке.")


def _detail(v) -> str:
    t = [f"<b>{v.title}</b>", f"Протокол: {E(v.protocol_label)}"]
    if v.is_placeholder:
        t.append("🧪 <i>Тестовая заглушка — это не рабочая конфигурация (VPN_MODE=mock).</i>")
    if v.error:
        t.append(f"⚠️ {v.error}")
    if v.link:
        t += ["", "Ссылка (нажмите, чтобы скопировать):", f"<code>{E(v.link)}</code>"]
    return "\n".join(t)


@router.callback_query(F.data == "conns")
async def conns(cb: CallbackQuery, svc, user):
    views = await svc.vpn.connections(user["id"])
    if not views:
        sub = await svc.subs.view(user["id"])
        text = ("🔑 <b>Мои подключения</b>\n\nУ вас нет активной подписки." if not sub or not sub["is_active"]
                else "🔑 Подключения готовятся — обычно это занимает не больше минуты.")
        return await render(cb, text, kb([[btn("🛒 Купить подписку", "shop", style="success")], [home()]]))
    await render(cb, "🔑 <b>Мои подключения</b>\n\nВыберите подключение:", conns_kb(views))


@router.callback_query(F.data.startswith("conn:"))
async def conn(cb: CallbackQuery, svc, user):
    iid = int(cb.data.split(":")[1])
    view = next((v for v in await svc.vpn.connections(user["id"]) if v.inbound_id == iid), None)
    if not view:
        return await alert(cb, "Подключение недоступно")
    await render(cb, _detail(view), conn_kb(view))


@router.callback_query(F.data.startswith("qr:"))
async def qr(cb: CallbackQuery, svc, user):
    iid = int(cb.data.split(":")[1])
    view = next((v for v in await svc.vpn.connections(user["id"]) if v.inbound_id == iid), None)
    if not view or not view.link:
        return await alert(cb, "Подключение недоступно")
    png = make_qr_png(view.link)
    await cb.message.answer_photo(BufferedInputFile(png, "flux-qr.png"), caption=view.title)
    await cb.answer()


@router.callback_query(F.data == "conns_all")
async def conns_all(cb: CallbackQuery, svc, user):
    views = [v for v in await svc.vpn.connections(user["id"]) if v.link]
    if not views:
        return await alert(cb, "Подключения недоступны")
    by_country: dict[str, list] = {}
    for v in views:
        by_country.setdefault(v.country, []).append(v)
    for code, items in by_country.items():
        flag, ru, _ = country_meta(code)
        body = "\n\n".join(f"<b>Подключение {v.position}</b> · {E(v.protocol_label)}\n<code>{E(v.link)}</code>"
                           for v in items)
        await cb.message.answer(f"{flag} <b>{ru}</b>\n\n{body}")
    await cb.answer()


@router.callback_query(F.data == "help")
async def help_(cb: CallbackQuery):
    await render(cb, HELP, kb([[btn("🔙 К подключениям", "conns", style="danger")], [home()]]))
