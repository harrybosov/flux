from datetime import datetime
from zoneinfo import ZoneInfo

from aiogram import F, Router
from aiogram.types import CallbackQuery

from admin import AdminFilter
from keyboards import back, btn, kb
from models import PROVIDER_TITLES
from utils import clock
from utils.ui import render

router = Router(name="admin_stats")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())


async def collect(db, tz: str) -> dict:
    now = clock.now()
    midnight = int(datetime.fromtimestamp(now, ZoneInfo(tz)).replace(hour=0, minute=0, second=0, microsecond=0).timestamp())

    async def one(sql, params=()):
        return (await db.fetchone(sql, params))["c"]

    return {
        "users": await one("SELECT COUNT(*) c FROM users"),
        "day": await one("SELECT COUNT(*) c FROM users WHERE created_at>=?", (midnight,)),
        "week": await one("SELECT COUNT(*) c FROM users WHERE created_at>=?", (now - 7 * 86400,)),
        "active": await one("SELECT COUNT(*) c FROM subscriptions WHERE status='ACTIVE' AND ends_at>?", (now,)),
        "expired": await one("SELECT COUNT(*) c FROM subscriptions WHERE status='EXPIRED' OR ends_at<=?", (now,)),
        "orders": await one("SELECT COUNT(*) c FROM orders"),
        "paid": await one("SELECT COUNT(*) c FROM payments WHERE status='PAID'"),
        "by_provider": await db.fetchall(
            "SELECT provider, currency, COUNT(*) c, SUM(amount) s FROM payments WHERE status='PAID' "
            "GROUP BY provider, currency ORDER BY provider"),
    }


def render_stats(s: dict) -> str:
    lines = ["📊 <b>Статистика</b>", "",
             f"👥 Пользователей: <b>{s['users']}</b>  (сегодня +{s['day']}, за 7 дней +{s['week']})",
             f"🟢 Активных подписок: <b>{s['active']}</b>", f"🔴 Просроченных: <b>{s['expired']}</b>",
             f"🧾 Заказов: <b>{s['orders']}</b>", f"✅ Подтверждённых платежей: <b>{s['paid']}</b>", "",
             "💰 Сумма платежей по провайдерам:"]
    if not s["by_provider"]:
        lines.append("— пока нет —")
    for r in s["by_provider"]:
        unit = "₽" if r["currency"] == "RUB" else ("⭐" if r["currency"] == "XTR" else r["currency"])
        lines.append(f"• {PROVIDER_TITLES.get(r['provider'], r['provider'])}: {r['s']} {unit} ({r['c']} шт.)")
    return "\n".join(lines)


@router.callback_query(F.data == "adm:stats")
async def stats(cb: CallbackQuery, svc):
    s = await collect(svc.db, svc.settings.timezone)
    await render(cb, render_stats(s), kb([[btn("🔄 Обновить", "adm:stats")], [back("adm")]]))
