from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from admin import AdminFilter, AdmStates
from keyboards import back, btn, kb
from utils import clock, texts
from utils.ui import alert, render

router = Router(name="admin_promos")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())
FORMAT = ("Формат: <code>КОД ДНИ [ЛИМИТ] [СРОК_ДЕЙСТВИЯ_ДНЕЙ]</code>\n"
          "Пример: <code>WELCOME7 7 100 30</code> — +7 дней, 100 использований, действует 30 дней.\n"
          "<code>0</code> вместо лимита или срока = без ограничений.")


def _parse(text: str, with_code: bool = True):
    parts = text.split()
    need = 2 if with_code else 1
    if len(parts) < need or len(parts) > need + 2:
        raise ValueError("Неверный формат")
    code = parts.pop(0) if with_code else None
    try:
        nums = [int(x) for x in parts]
    except ValueError as e:
        raise ValueError("Числа указаны неверно") from e
    days = nums[0]
    limit = nums[1] if len(nums) > 1 and nums[1] > 0 else None
    valid = clock.now() + nums[2] * 86400 if len(nums) > 2 and nums[2] > 0 else None
    return code, days, limit, valid


def _line(p: dict) -> str:
    return (f"{'🟢' if p['is_active'] else '⚪️'} <code>{p['code']}</code> · +{p['bonus_days']} дн. · "
            f"{p['used_count']}/{p['max_uses'] or '∞'}")


@router.callback_query(F.data == "adm:promos")
async def promos(cb: CallbackQuery, svc, state: FSMContext):
    await state.clear()
    items = await svc.promo.list()
    rows = [[btn(_line(p).replace("<code>", "").replace("</code>", ""), f"adm:p:{p['id']}")] for p in items]
    rows.append([btn("➕ Создать промокод", "adm:p_new", style="success")])
    rows.append([back("adm")])
    await render(cb, "🎟 <b>Промокоды</b>", kb(rows))


@router.callback_query(F.data.startswith("adm:p:"))
async def promo_view(cb: CallbackQuery, svc):
    await _show_promo(cb, svc, int(cb.data.split(":")[2]))


async def _show_promo(cb: CallbackQuery, svc, promo_id: int):
    p = await svc.promo.get(promo_id)
    if not p:
        return await alert(cb, "Не найден")
    tz = svc.settings.timezone
    text = (f"🎟 <b>{p['code']}</b>\n\nБонус: +{texts.fmt_days(p['bonus_days'])}\n"
            f"Использований: {p['used_count']} из {p['max_uses'] or '∞'}\n"
            f"Действует до: {texts.fmt_dt(p['expires_at'], tz) if p['expires_at'] else 'без срока'}\n"
            f"Статус: {'🟢 включён' if p['is_active'] else '⚪️ отключён'}\nОдин раз на пользователя: да")
    await render(cb, text, kb([
        [btn("⏸ Отключить" if p["is_active"] else "▶️ Включить", f"adm:p_tg:{p['id']}")],
        [btn("✏️ Изменить", f"adm:p_edit:{p['id']}"), btn("🗑 Удалить", f"adm:p_del:{p['id']}", style="danger")],
        [back("adm:promos")]]))


@router.callback_query(F.data.startswith("adm:p_tg:"))
async def promo_toggle(cb: CallbackQuery, svc):
    p = await svc.promo.get(int(cb.data.split(":")[2]))
    await svc.promo.set_active(p["id"], not p["is_active"])
    await svc.admin_log(cb.from_user.id, "promo_toggle", p["code"])
    await _show_promo(cb, svc, p["id"])


@router.callback_query(F.data.startswith("adm:p_del:"))
async def promo_delete(cb: CallbackQuery, svc):
    pid = int(cb.data.split(":")[2])
    p = await svc.promo.get(pid)
    if not p:
        return await alert(cb, "Не найден")
    await render(cb, f"Удалить промокод <b>{p['code']}</b>? История использований тоже будет удалена.",
                 kb([[btn("🗑 Да, удалить", f"adm:p_delok:{pid}", style="danger")], [back(f"adm:p:{pid}", "Отмена")]]))


@router.callback_query(F.data.startswith("adm:p_delok:"))
async def promo_delete_ok(cb: CallbackQuery, svc, state: FSMContext):
    pid = int(cb.data.split(":")[2])
    p = await svc.promo.get(pid)
    await svc.promo.delete(pid)
    await svc.admin_log(cb.from_user.id, "promo_delete", p["code"] if p else str(pid))
    await promos(cb, svc, state)


@router.callback_query(F.data == "adm:p_new")
async def promo_new(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdmStates.promo_new)
    await render(cb, "➕ <b>Новый промокод</b>\n\n" + FORMAT, kb([[back("adm:promos", "Отмена")]]))


@router.message(AdmStates.promo_new, F.text)
async def promo_new_msg(msg: Message, state: FSMContext, svc):
    try:
        code, days, limit, valid = _parse(msg.text)
        p = await svc.promo.create(code, days, limit, valid)
    except ValueError as e:
        return await msg.answer(f"❌ {e}\n\n{FORMAT}")
    await state.clear()
    await svc.admin_log(msg.from_user.id, "promo_create", p["code"], f"+{days}d limit={limit}")
    await msg.answer(f"✅ Создан: {_line(p)}", reply_markup=kb([[back("adm:promos", "К промокодам")]]))


@router.callback_query(F.data.startswith("adm:p_edit:"))
async def promo_edit(cb: CallbackQuery, state: FSMContext):
    pid = int(cb.data.split(":")[2])
    await state.set_state(AdmStates.promo_edit)
    await state.update_data(pid=pid)
    await render(cb, "✏️ Отправьте: <code>ДНИ [ЛИМИТ] [СРОК_ДЕЙСТВИЯ_ДНЕЙ]</code> (<code>0</code> = без ограничений).",
                 kb([[back(f"adm:p:{pid}", "Отмена")]]))


@router.message(AdmStates.promo_edit, F.text)
async def promo_edit_msg(msg: Message, state: FSMContext, svc):
    pid = (await state.get_data())["pid"]
    try:
        _, days, limit, valid = _parse(msg.text, with_code=False)
        await svc.promo.update(pid, days, limit, valid)
    except ValueError as e:
        return await msg.answer(f"❌ {e}")
    await state.clear()
    await svc.admin_log(msg.from_user.id, "promo_edit", str(pid))
    await msg.answer("✅ Сохранено", reply_markup=kb([[back(f"adm:p:{pid}", "К промокоду")]]))
