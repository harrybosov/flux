from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from admin import AdminFilter
from keyboards import btn, home, kb
from utils.ui import render

router = Router(name="admin_dashboard")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())

TEXT = "🛠 <b>Админ-панель</b>"


def admin_menu():
    return kb([
        [btn("📊 Статистика", "adm:stats"), btn("👥 Пользователи", "adm:users")],
        [btn("💳 Платежи", "adm:pay"), btn("🎟 Промокоды", "adm:promos")],
        [btn("📢 Рассылка", "adm:bc"), btn("⚙️ Настройки", "adm:set")],
        [home()],
    ])


@router.message(Command("admin"))
async def admin_cmd(msg: Message, state: FSMContext):
    await state.clear()
    await msg.answer(TEXT, reply_markup=admin_menu())


@router.callback_query(F.data == "adm")
async def admin_cb(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await render(cb, TEXT, admin_menu())
