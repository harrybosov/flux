import logging

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from admin import AdminFilter, AdmStates
from keyboards import back, btn, kb
from models import OrderStatus, PROVIDER_TITLES, Provider
from utils import texts
from utils.ui import alert, render

log = logging.getLogger(__name__)
router = Router(name="admin_payments")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())
E = texts.E
PAGE = 8
SHORT = {"S": Provider.STARS, "C": Provider.CRYPTOBOT, "D": Provider.DONATEALERTS}
SHORT_REV = {v: k for k, v in SHORT.items()}
STAT = {"P": OrderStatus.PENDING, "D": OrderStatus.PAID, "E": OrderStatus.EXPIRED,
        "C": OrderStatus.CANCELLED, "R": OrderStatus.REFUNDED}
STAT_REV = {v: k for k, v in STAT.items()}


@router.callback_query(F.data == "adm:pay")
async def pay_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    prov = [btn("Все", "adm:pl:-:-:0")] + [btn(PROVIDER_TITLES[p], f"adm:pl:{k}:-:0") for k, p in SHORT.items()]
    stat = [btn(f"{texts.STATUS_EMOJI[s]} {texts.STATUS_RU[s]}", f"adm:pl:-:{k}:0") for k, s in STAT.items()]
    await render(cb, "💳 <b>Платежи</b>\n\nПросмотр заказов: фильтр по провайдеру или статусу.",
                 kb([prov[:2], prov[2:], stat[:2], stat[2:4], stat[4:], [btn("🔎 Поиск по ID заказа", "adm:osearch")],
                     [back("adm")]]))


@router.callback_query(F.data.startswith("adm:pl:"))
async def pay_list(cb: CallbackQuery, svc):
    _, _, p, s, off = cb.data.split(":")
    off = int(off)
    provider, status = SHORT.get(p), STAT.get(s)
    orders = await svc.orders.list_filtered(provider, status, PAGE + 1, off)
    more = len(orders) > PAGE
    orders = orders[:PAGE]
    tz = svc.settings.timezone
    rows = [[btn(f"{texts.STATUS_EMOJI[o['status']]} {o['public_id']} · {texts.fmt_money(o['amount'], o['currency'])} · "
                 f"{texts.fmt_date(o['created_at'], tz)}", f"adm:o:{o['id']}")] for o in orders]
    nav = []
    if off > 0:
        nav.append(btn("◀️", f"adm:pl:{p}:{s}:{max(0, off - PAGE)}"))
    if more:
        nav.append(btn("▶️", f"adm:pl:{p}:{s}:{off + PAGE}"))
    if nav:
        rows.append(nav)
    rows.append([back("adm:pay")])
    title = f"💳 Заказы · {PROVIDER_TITLES[provider] if provider else 'все'} · {texts.STATUS_RU[status] if status else 'все статусы'}"
    await render(cb, title + ("" if orders else "\n\nНичего не найдено."), kb(rows))


async def order_card(svc, order: dict):
    tz = svc.settings.timezone
    user = await svc.users.get(order["user_id"])
    pay = await svc.orders.payment_for_order(order["id"])
    lines = [f"🧾 <b>Заказ</b> <code>{order['public_id']}</code>",
             f"Пользователь: <code>{user['tg_id']}</code>", f"Тариф: {E(order['plan_name'])} ({texts.fmt_days(order['days'])})",
             f"Сумма: {texts.fmt_money(order['amount'], order['currency'])} · {PROVIDER_TITLES[order['provider']]}",
             f"Статус: {texts.STATUS_EMOJI[order['status']]} {texts.STATUS_RU[order['status']]}",
             f"Создан: {texts.fmt_dt(order['created_at'], tz)}", f"Оплачен: {texts.fmt_dt(order['paid_at'], tz)}",
             f"ID счёта: <code>{E(order['external_id'] or '—')}</code>"]
    if pay:
        lines.append(f"ID платежа: <code>{E(pay['external_id'])}</code> ({pay['provider']})")
    rows = []
    if order["status"] in (OrderStatus.PENDING, OrderStatus.EXPIRED) and order["provider"] == Provider.DONATEALERTS:
        rows.append([btn("✅ Подтвердить вручную", f"adm:da_ok:{order['id']}", style="success")])
    if order["status"] == OrderStatus.PENDING:
        rows.append([btn("🚫 Отменить", f"adm:da_no:{order['id']}", style="danger")])
    if order["status"] == OrderStatus.PAID and order["provider"] == Provider.STARS:
        rows.append([btn("↩️ Вернуть Stars", f"adm:refund:{order['id']}", style="danger")])
    rows.append([back("adm:pay")])
    return "\n".join(lines), kb(rows)


@router.callback_query(F.data.startswith("adm:o:"))
async def order_view(cb: CallbackQuery, svc):
    order = await svc.orders.get(int(cb.data.split(":")[2]))
    if not order:
        return await alert(cb, "Заказ не найден")
    text, markup = await order_card(svc, order)
    await render(cb, text, markup)


@router.callback_query(F.data == "adm:osearch")
async def order_search_prompt(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdmStates.order_search)
    await render(cb, "🔎 Отправьте ID заказа (например <code>FX-1A2B3C4D</code>).", kb([[back("adm:pay")]]))


@router.message(AdmStates.order_search, F.text)
async def order_search(msg: Message, state: FSMContext, svc):
    order = await svc.orders.get_by_public(msg.text.strip())
    if not order:
        return await msg.answer("Заказ не найден.")
    await state.clear()
    text, markup = await order_card(svc, order)
    await msg.answer(text, reply_markup=markup)


@router.callback_query(F.data.startswith("adm:da_ok:"))
async def da_confirm(cb: CallbackQuery, svc):
    if svc.donate is None:
        return await alert(cb, "DonateAlerts не настроен")
    order_id = int(cb.data.split(":")[2])
    out = await svc.donate.manual_confirm(order_id, cb.from_user.id)
    await svc.admin_log(cb.from_user.id, "manual_confirm", str(order_id), out.status if out else "none")
    await alert(cb, {"ok": "✅ Подтверждено, подписка выдана", "duplicate": "Уже подтверждено",
                     "already_paid": "Заказ уже оплачен"}.get(out.status if out else "", "Не удалось подтвердить"))
    order = await svc.orders.get(order_id)
    if order:
        text, markup = await order_card(svc, order)
        await render(cb, text, markup)


@router.callback_query(F.data.startswith("adm:da_no:"))
async def da_reject(cb: CallbackQuery, svc):
    order_id = int(cb.data.split(":")[2])
    done = await svc.orders.cancel(order_id)
    await svc.admin_log(cb.from_user.id, "cancel_order", str(order_id))
    order = await svc.orders.get(order_id)
    if done and order:
        user = await svc.users.get(order["user_id"])
        await svc.notifier.send(user["tg_id"], f"🚫 Заказ <code>{order['public_id']}</code> отменён администратором.")
    await alert(cb, "Заказ отменён" if done else "Нельзя отменить")


@router.callback_query(F.data.startswith("adm:refund:"))
async def stars_refund(cb: CallbackQuery, svc):
    order = await svc.orders.get(int(cb.data.split(":")[2]))
    if not order or svc.stars is None:
        return await alert(cb, "Недоступно")
    ok, msg = await svc.stars.refund(order)
    await svc.admin_log(cb.from_user.id, "refund_stars", order["public_id"], msg)
    if ok:
        user = await svc.users.get(order["user_id"])
        await svc.notifier.send(user["tg_id"], f"↩️ Stars по заказу <code>{order['public_id']}</code> возвращены. "
                                               "Срок подписки уменьшен на срок этого заказа.")
    await alert(cb, msg[:190])
    text, markup = await order_card(svc, await svc.orders.get(order["id"]))
    await render(cb, text, markup)


@router.message(Command("refund_stars"))
async def refund_raw(msg: Message, command: CommandObject, svc):
    """Аварийный возврат: /refund_stars <tg_id> <charge_id> (если платёж не удалось обработать)."""
    args = (command.args or "").split()
    if len(args) != 2 or not args[0].isdigit():
        return await msg.answer("Формат: /refund_stars <telegram_id> <charge_id>")
    try:
        await svc.bot.refund_star_payment(user_id=int(args[0]), telegram_payment_charge_id=args[1])
    except Exception as e:  # noqa: BLE001
        return await msg.answer(f"Telegram отклонил возврат: {E(str(e))}")
    await svc.admin_log(msg.from_user.id, "refund_stars_raw", args[0], args[1])
    await msg.answer("↩️ Возврат выполнен.")
