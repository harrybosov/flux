"""Админ-панель. Доступ только по ADMIN_IDS (проверяется фильтром на уровне каждого роутера)."""
from aiogram.filters import BaseFilter
from aiogram.fsm.state import State, StatesGroup


class AdminFilter(BaseFilter):
    async def __call__(self, event, svc) -> bool:
        u = getattr(event, "from_user", None)
        return bool(u and svc.settings.is_admin(u.id))


class AdmStates(StatesGroup):
    user_search = State()
    order_search = State()
    promo_new = State()
    promo_edit = State()
    plan_value = State()
    ref_bonus = State()
    bc_text = State()
    bc_confirm = State()
