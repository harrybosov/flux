"""Единый источник времени (unix-секунды, UTC). Можно «заморозить» в тестах."""
import time

_frozen: int | None = None


def now() -> int:
    return _frozen if _frozen is not None else int(time.time())


def freeze(ts: int) -> None:
    global _frozen
    _frozen = int(ts)


def advance(seconds: int) -> None:
    global _frozen
    _frozen = (now() if _frozen is None else _frozen) + int(seconds)


def unfreeze() -> None:
    global _frozen
    _frozen = None
