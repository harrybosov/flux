"""Тонкая обёртка над aiohttp для провайдеров (легко подменяется в тестах)."""
from __future__ import annotations

import asyncio
import json
from typing import Any


class HttpError(Exception):
    pass


class HttpClient:
    def __init__(self, timeout: float = 20.0):
        self._timeout = timeout
        self._session = None

    async def request(self, method: str, url: str, *, headers: dict | None = None, json_body: Any = None,
                      form: dict | None = None, params: dict | None = None) -> tuple[int, Any, str]:
        import aiohttp
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self._timeout))
        try:
            async with self._session.request(method, url, headers=headers, json=json_body, data=form,
                                             params=params) as r:
                text = await r.text()
                try:
                    body = json.loads(text)
                except ValueError:
                    body = None
                return r.status, body, text
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            raise HttpError(f"{type(e).__name__}: {e}") from e

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
