"""Адаптер панели 3X-UI (по документированным маршрутам репозитория MHSanaei/3x-ui):

  POST /login                                  (username, password)
  GET  /panel/api/inbounds/get/:id
  POST /panel/api/inbounds/addClient           {"id": <inbound>, "settings": "{\"clients\":[...]}"}
  POST /panel/api/inbounds/updateClient/:clientId   (clientId: id для VMess/VLESS, password для Trojan, email для Shadowsocks)

Ответы панели: {"success": bool, "msg": str, "obj": ...}.
ПРОВЕРЬТЕ маршруты и поля на вашей версии панели (3.11.0) командой `python -m scripts.check_xui`.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import secrets as _secrets
import time
import uuid
from typing import Any, Protocol

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # импорт только для аннотаций
    from config import NodeConfig
from vpn import links
from vpn.base import (ClientState, LinkInfo, PanelAdapter, PanelAuthError, PanelConnectionError,
                      PanelError, UnsupportedProtocol)

log = logging.getLogger(__name__)
SUPPORTED = {"vless", "vmess", "trojan", "shadowsocks"}


class Transport(Protocol):
    async def request(self, method: str, url: str, *, json_body: Any = None,
                      form: dict | None = None) -> tuple[int, Any, str]: ...
    async def close(self) -> None: ...


class AiohttpTransport:
    def __init__(self, verify_ssl: bool = True, timeout: float = 20.0):
        self._verify = verify_ssl
        self._timeout = timeout
        self._session = None

    async def _get(self):
        import aiohttp
        if self._session is None or self._session.closed:
            # unsafe=True: иначе aiohttp не сохраняет cookie для IP-адресов (панель часто открыта по IP)
            kw = {} if self._verify else {"connector": aiohttp.TCPConnector(ssl=False)}
            self._session = aiohttp.ClientSession(
                cookie_jar=aiohttp.CookieJar(unsafe=True),
                timeout=aiohttp.ClientTimeout(total=self._timeout), **kw)
        return self._session

    async def request(self, method, url, *, json_body=None, form=None):
        import aiohttp
        session = await self._get()
        try:
            async with session.request(method, url, json=json_body, data=form) as r:
                text = await r.text()
                try:
                    body = json.loads(text)
                except ValueError:
                    body = None
                return r.status, body, text
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            raise PanelConnectionError(f"{type(e).__name__}: {e}") from e

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()


def _client_key(protocol: str, client: dict) -> str:
    return {"vless": client.get("id"), "vmess": client.get("id"),
            "trojan": client.get("password"), "shadowsocks": client.get("email")}[protocol]


class XuiAdapter(PanelAdapter):
    def __init__(self, node: NodeConfig, transport: Transport | None = None, limit_ip: int = 0,
                 inbound_cache_ttl: float = 30.0):
        self.key = node.key
        self._node = node
        self._base = node.base_url.rstrip("/")
        self._t: Transport = transport or AiohttpTransport(node.verify_ssl)
        self._limit_ip = limit_ip
        self._logged_in = False
        self._login_lock = asyncio.Lock()
        self._io_lock = asyncio.Lock()      # изменения клиентов в одной панели — строго по очереди
        self._cache: dict[int, tuple[float, dict]] = {}
        self._ttl = inbound_cache_ttl

    # ---------- HTTP ----------
    async def _login(self) -> None:
        async with self._login_lock:
            status, body, text = await self._t.request(
                "POST", f"{self._base}/login",
                form={"username": self._node.username, "password": self._node.password})
            if status != 200 or not isinstance(body, dict) or not body.get("success"):
                msg = body.get("msg") if isinstance(body, dict) else f"HTTP {status}"
                raise PanelAuthError(f"[{self.key}] вход в панель не удался: {msg}")
            self._logged_in = True

    async def _call(self, method: str, path: str, *, json_body: Any = None, _retry: bool = True) -> Any:
        if not self._logged_in:
            await self._login()
        status, body, text = await self._t.request(method, f"{self._base}{path}", json_body=json_body)
        # 3X-UI отвечает 404 на /panel/api/* без валидной сессии → перелогин и один повтор
        if status in (401, 403, 404) and _retry:
            self._logged_in = False
            return await self._call(method, path, json_body=json_body, _retry=False)
        if status >= 400:
            raise PanelError(f"[{self.key}] HTTP {status} на {path}")
        if not isinstance(body, dict):
            raise PanelError(f"[{self.key}] ответ панели не JSON на {path}")
        if not body.get("success"):
            raise PanelError(f"[{self.key}] панель отклонила запрос {path}: {body.get('msg') or 'без сообщения'}")
        return body.get("obj")

    async def _get_inbound(self, pid: int, fresh: bool = False) -> dict:
        hit = self._cache.get(pid)
        if hit and not fresh and time.monotonic() - hit[0] < self._ttl:
            return hit[1]
        obj = await self._call("GET", f"/panel/api/inbounds/get/{pid}")
        if not isinstance(obj, dict):
            raise PanelError(f"[{self.key}] inbound {pid} не найден")
        self._cache[pid] = (time.monotonic(), obj)
        return obj

    # ---------- клиенты ----------
    def _new_client(self, protocol: str, inbound: dict, email: str, secret: str | None,
                    expiry_ms: int, enabled: bool, comment: str) -> dict:
        base = {"email": email, "limitIp": self._limit_ip, "totalGB": 0, "expiryTime": expiry_ms,
                "enable": enabled, "tgId": "", "subId": _secrets.token_hex(8), "comment": comment, "reset": 0}
        if protocol == "vless":
            stream = links.loads(inbound.get("streamSettings"))
            flow = ""
            if (stream.get("network") or "tcp") == "tcp" and (stream.get("security") in ("reality", "tls")):
                flow = "xtls-rprx-vision"
            return {"id": secret or str(uuid.uuid4()), "flow": flow, **base}
        if protocol == "vmess":
            return {"id": secret or str(uuid.uuid4()), "security": "auto", **base}
        if protocol == "trojan":
            return {"password": secret or _secrets.token_urlsafe(12), **base}
        if protocol == "shadowsocks":
            method = links.loads(inbound.get("settings")).get("method", "")
            if method.startswith("2022-blake3-aes-128"):
                pw = base64.b64encode(_secrets.token_bytes(16)).decode()
            elif method.startswith("2022-"):
                pw = base64.b64encode(_secrets.token_bytes(32)).decode()
            else:
                pw = _secrets.token_urlsafe(12)
            return {"method": method, "password": secret or pw, **base}
        raise UnsupportedProtocol(f"[{self.key}] протокол '{protocol}' не поддерживается")

    @staticmethod
    def _find(inbound: dict, email: str) -> dict | None:
        for c in links.loads(inbound.get("settings")).get("clients", []) or []:
            if c.get("email") == email:
                return c
        return None

    async def ensure_client(self, panel_inbound_id, email, secret, expiry_ts, enabled, comment=""):
        expiry_ms = int(expiry_ts) * 1000
        async with self._io_lock:
            inbound = await self._get_inbound(panel_inbound_id, fresh=True)
            protocol = (inbound.get("protocol") or "").lower()
            if protocol not in SUPPORTED:
                raise UnsupportedProtocol(f"[{self.key}] inbound {panel_inbound_id}: протокол '{protocol}' "
                                          f"не поддерживается (поддерживаются: {', '.join(sorted(SUPPORTED))})")
            existing = self._find(inbound, email)
            if existing is None:
                client = self._new_client(protocol, inbound, email, secret, expiry_ms, enabled, comment)
                await self._call("POST", "/panel/api/inbounds/addClient",
                                 json_body={"id": panel_inbound_id, "settings": json.dumps({"clients": [client]})})
                created = True
            else:
                client = {**existing, "expiryTime": expiry_ms, "enable": enabled}
                if self._limit_ip and not client.get("limitIp"):
                    client["limitIp"] = self._limit_ip
                await self._call("POST", f"/panel/api/inbounds/updateClient/{_client_key(protocol, existing)}",
                                 json_body={"id": panel_inbound_id, "settings": json.dumps({"clients": [client]})})
                created = False
            # проверка записи: известны случаи, когда панель отвечает 200, но изменения не сохраняет
            self._cache.pop(panel_inbound_id, None)
            after = await self._get_inbound(panel_inbound_id, fresh=True)
            got = self._find(after, email)
            if got is None:
                raise PanelError(f"[{self.key}] клиент {email} не найден после записи")
            if int(got.get("expiryTime", -1)) != expiry_ms or bool(got.get("enable")) != bool(enabled):
                raise PanelError(f"[{self.key}] панель не применила изменения клиента {email}")
            return ClientState(_client_key(protocol, got), protocol, links.protocol_label(after),
                               expiry_ts, bool(got.get("enable")), created)

    async def get_client(self, panel_inbound_id, email):
        inbound = await self._get_inbound(panel_inbound_id, fresh=True)
        c = self._find(inbound, email)
        if c is None:
            return None
        protocol = (inbound.get("protocol") or "").lower()
        return ClientState(_client_key(protocol, c), protocol, links.protocol_label(inbound),
                           int(c.get("expiryTime", 0)) // 1000, bool(c.get("enable")))

    async def build_link(self, panel_inbound_id, email, secret, remark):
        inbound = await self._get_inbound(panel_inbound_id)
        client = self._find(inbound, email)
        if client is None:
            raise PanelError(f"[{self.key}] клиент {email} не найден в панели")
        link = links.build_link(inbound, self._node.public_host, client, remark)
        return LinkInfo(links.protocol_label(inbound), link)

    async def close(self):
        await self._t.close()
