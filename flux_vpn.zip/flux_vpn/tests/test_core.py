"""Регистрация, тарифы, заказы, продление, истечение, промокоды, рефералы, права админа."""
import os
import unittest

from services.promo import (PromoAlreadyUsed, PromoDisabled, PromoError, PromoExhausted, PromoExpired,
                            PromoNotFound)
from services.orders import OrderError
from tests.helpers import DAY, T0, BaseCase
from utils import clock


class UsersAndPlans(BaseCase):
    async def test_registration_creates_once_and_updates_profile(self):
        u, created = await self.env.users.upsert_from_telegram(10, "a", "A", None)
        self.assertTrue(created)
        u2, created2 = await self.env.users.upsert_from_telegram(10, "newname", "A", None)
        self.assertFalse(created2)
        self.assertEqual(u["id"], u2["id"])
        self.assertEqual(u2["username"], "newname")

    async def test_referral_rules(self):
        ref = await self.new_user(1)
        invited = await self.new_user(2, ref=1)
        self.assertEqual(invited["referrer_id"], ref["id"])
        # самоприглашение игнорируется
        me, _ = await self.env.users.upsert_from_telegram(3, "s", "S", None, ref_tg_id=3)
        self.assertIsNone(me["referrer_id"])
        # уже зарегистрированного пользователя перепривязать нельзя
        again, created = await self.env.users.upsert_from_telegram(1, "x", "X", None, ref_tg_id=2)
        self.assertFalse(created)
        self.assertIsNone(again["referrer_id"])
        # несуществующий реферер
        z, _ = await self.env.users.upsert_from_telegram(4, "z", "Z", None, ref_tg_id=999)
        self.assertIsNone(z["referrer_id"])

    async def test_tariffs_seeded_per_spec(self):
        plans = {p["id"]: (p["days"], p["price_rub"]) for p in await self.env.plans.list_active()}
        self.assertEqual(plans, {"test": (7, 30), "m1": (30, 100), "m3": (90, 270),
                                 "m6": (180, 490), "y1": (365, 890)})

    async def test_admin_can_edit_plan_and_stars_price(self):
        await self.env.plans.update("m1", price_rub=120, days=31, is_active=True)
        p = await self.env.plans.get("m1")
        self.assertEqual((p["price_rub"], p["days"]), (120, 31))
        self.assertIsNone(await self.env.plans.stars_price("m1"))
        await self.env.plans.set_stars_price("m1", 75)
        self.assertEqual(await self.env.plans.stars_price("m1"), 75)
        await self.env.plans.set_stars_price("m1", None)
        self.assertIsNone(await self.env.plans.stars_price("m1"))
        await self.env.plans.update("m1", is_active=False)
        self.assertNotIn("m1", [x["id"] for x in await self.env.plans.list_active()])


class Orders(BaseCase):
    async def test_create_order_snapshot_and_reuse(self):
        u = await self.new_user()
        o1 = await self.env.orders.create_order(u["id"], "m3", "CRYPTOBOT")
        self.assertEqual((o1["amount"], o1["currency"], o1["days"], o1["status"]), (270, "RUB", 90, "PENDING"))
        self.assertTrue(o1["public_id"].startswith("FX-"))
        o2 = await self.env.orders.create_order(u["id"], "m3", "CRYPTOBOT")
        self.assertEqual(o1["id"], o2["id"])           # неоплаченный заказ переиспользуется

    async def test_stars_order_requires_configured_price(self):
        u = await self.new_user()
        with self.assertRaises(OrderError):
            await self.env.orders.create_order(u["id"], "m1", "STARS")
        await self.env.plans.set_stars_price("m1", 80)
        o = await self.env.orders.create_order(u["id"], "m1", "STARS")
        self.assertEqual((o["amount"], o["currency"]), (80, "XTR"))

    async def test_inactive_plan_and_unknown_provider_rejected(self):
        u = await self.new_user()
        await self.env.plans.update("y1", is_active=False)
        with self.assertRaises(OrderError):
            await self.env.orders.create_order(u["id"], "y1", "CRYPTOBOT")
        with self.assertRaises(OrderError):
            await self.env.orders.create_order(u["id"], "m1", "PAYPAL")

    async def test_stale_orders_expire(self):
        u = await self.new_user()
        o = await self.env.orders.create_order(u["id"], "m1", "CRYPTOBOT")
        clock.advance(2 * 3600)
        self.assertEqual(await self.env.orders.expire_stale(), 1)
        self.assertEqual((await self.env.orders.get(o["id"]))["status"], "EXPIRED")


class Subscriptions(BaseCase):
    async def test_no_access_before_payment(self):
        u = await self.new_user()
        await self.env.orders.create_order(u["id"], "m1", "CRYPTOBOT")
        self.assertIsNone(await self.env.subs.get(u["id"]))
        self.assertEqual(await self.env.vpn.connections(u["id"]), [])
        self.assertEqual(self.env.adapters["DE"].calls, [])

    async def test_payment_activates_and_provisions_all_six(self):
        u = await self.new_user()
        order, out = await self.paid_order(u, "m1")
        self.assertEqual(out.status, "ok")
        sub = await self.env.subs.view(u["id"])
        self.assertEqual(sub["ends_at"], T0 + 30 * DAY)
        self.assertTrue(sub["is_active"])
        self.assertEqual(sub["vpn_dirty"], 0)
        self.assertEqual(await self.env.vpn.count_clients(u["id"]), 6)
        self.assertEqual(len(await self.env.vpn.connections(u["id"])), 6)
        self.assertTrue(any("Подписка активна" in t for _, t in self.env.notifier.sent))

    async def test_renewal_adds_to_current_end_date(self):
        u = await self.new_user()
        await self.paid_order(u, "m1", ext="a")
        clock.advance(10 * DAY)
        _, out = await self.paid_order(u, "m3", ext="b")
        self.assertTrue(out.was_active_before)
        sub = await self.env.subs.get(u["id"])
        self.assertEqual(sub["ends_at"], T0 + 30 * DAY + 90 * DAY)   # не сбрасывается на «сейчас»

    async def test_renewal_after_expiry_starts_from_now(self):
        u = await self.new_user()
        await self.paid_order(u, "test", ext="a")
        clock.advance(20 * DAY)
        await self.paid_order(u, "m1", ext="b")
        sub = await self.env.subs.get(u["id"])
        self.assertEqual(sub["ends_at"], T0 + 20 * DAY + 30 * DAY)

    async def test_expiry_disables_vpn_clients(self):
        u = await self.new_user()
        await self.paid_order(u, "test")
        clock.advance(8 * DAY)
        due = await self.env.subs.due_for_expiry()
        self.assertEqual(len(due), 1)
        self.assertTrue(await self.env.subs.mark_expired(due[0]["id"]))
        self.assertFalse(await self.env.subs.mark_expired(due[0]["id"]))   # повтор безопасен
        res = await self.env.vpn.sync_user(u["id"])
        self.assertTrue(res.ok)
        self.assertTrue(all(not c["enabled"] for a in self.env.adapters.values() for c in a.clients.values()))
        self.assertEqual(await self.env.vpn.connections(u["id"]), [])

    async def test_reminder_selection_windows(self):
        from services.scheduler import REMINDERS
        h = 3600
        self.assertEqual([k for k, lim in REMINDERS if 60 * h <= lim], ["EXPIRE_3D"])
        self.assertEqual([k for k, lim in REMINDERS if 20 * h <= lim], ["EXPIRE_3D", "EXPIRE_1D"])
        self.assertEqual([k for k, lim in REMINDERS if 2 * h <= lim], ["EXPIRE_3D", "EXPIRE_1D", "EXPIRE_TODAY"])


class Promo(BaseCase):
    async def test_redeem_extends_and_counts(self):
        u = await self.new_user()
        await self.env.promo.create("Welcome7", 7, max_uses=5)
        promo, sub = await self.env.promo.redeem(u["id"], " welcome7 ")
        self.assertEqual(sub["ends_at"], T0 + 7 * DAY)
        self.assertEqual((await self.env.promo.get(promo["id"]))["used_count"], 1)

    async def test_not_twice_per_user(self):
        u = await self.new_user()
        await self.env.promo.create("ONCE", 3)
        await self.env.promo.redeem(u["id"], "once")
        with self.assertRaises(PromoAlreadyUsed):
            await self.env.promo.redeem(u["id"], "ONCE")

    async def test_limit_expiry_disabled_unknown(self):
        a, b = await self.new_user(1), await self.new_user(2)
        p = await self.env.promo.create("LIM", 3, max_uses=1)
        await self.env.promo.redeem(a["id"], "LIM")
        with self.assertRaises(PromoExhausted):
            await self.env.promo.redeem(b["id"], "LIM")
        await self.env.promo.create("OLD", 3, expires_at=T0 - 1)
        with self.assertRaises(PromoExpired):
            await self.env.promo.redeem(b["id"], "OLD")
        q = await self.env.promo.create("OFF", 3)
        await self.env.promo.set_active(q["id"], False)
        with self.assertRaises(PromoDisabled):
            await self.env.promo.redeem(b["id"], "OFF")
        with self.assertRaises(PromoNotFound):
            await self.env.promo.redeem(b["id"], "NOPE")
        with self.assertRaises(ValueError):
            await self.env.promo.create("LIM", 3)           # дубликат

    async def test_failed_redeem_changes_nothing(self):
        u = await self.new_user()
        with self.assertRaises(PromoError):
            await self.env.promo.redeem(u["id"], "NOPE")
        self.assertIsNone(await self.env.subs.get(u["id"]))


class Referrals(BaseCase):
    async def test_bonus_only_after_confirmed_first_purchase_and_once(self):
        ref = await self.new_user(1)
        inv = await self.new_user(2, ref=1)
        self.assertEqual((await self.env.users.get(ref["id"]))["bonus_days"], 0)   # регистрация бонус не даёт
        await self.env.orders.create_order(inv["id"], "m1", "CRYPTOBOT")            # неоплаченный заказ — тоже
        self.assertEqual((await self.env.users.get(ref["id"]))["bonus_days"], 0)
        _, out = await self.paid_order(inv, "m1", ext="a")
        self.assertEqual(out.reward["bonus_days"], 3)
        self.assertEqual((await self.env.users.get(ref["id"]))["bonus_days"], 3)
        await self.env.fulfillment.confirm(out.order["id"], source="CRYPTOBOT", external_id="a",
                                           amount=100, currency="RUB")             # повтор того же платежа
        await self.paid_order(inv, "m3", ext="b")                                   # вторая покупка
        self.assertEqual((await self.env.users.get(ref["id"]))["bonus_days"], 3)
        st = await self.env.referrals.stats(ref["id"])
        self.assertEqual((st["invited"], st["purchases"], st["balance_days"]), (1, 1, 3))

    async def test_claim_balance_extends_subscription(self):
        ref = await self.new_user(1)
        inv = await self.new_user(2, ref=1)
        await self.paid_order(inv, "m1")
        days, sub = await self.env.referrals.claim_balance(ref["id"])
        self.assertEqual((days, sub["ends_at"]), (3, T0 + 3 * DAY))
        self.assertIsNone(await self.env.referrals.claim_balance(ref["id"]))


class AdminRights(unittest.TestCase):
    def test_only_listed_ids_are_admins(self):
        from config import Settings
        old = dict(os.environ)
        try:
            os.environ.update({"ADMIN_IDS": "11, 22", "BOT_TOKEN": "x", "VPN_MODE": "mock"})
            s = Settings.load(env_file="/nonexistent")
            self.assertTrue(s.is_admin(11) and s.is_admin(22))
            self.assertFalse(s.is_admin(33) or s.is_admin(None))
        finally:
            os.environ.clear(); os.environ.update(old)


if __name__ == "__main__":
    unittest.main()
