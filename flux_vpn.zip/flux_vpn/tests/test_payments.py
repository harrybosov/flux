"""Платёжные сценарии на тестовых заглушках. Реальные транзакции НЕ выполняются."""
import hashlib
import hmac
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

from payments.cryptobot import CryptoBotProvider, verify_signature
from payments.donatealerts import DonateAlertsProvider, extract_code, match_donation
from payments.telegram_stars import StarsProvider
from tests.helpers import DAY, T0, BaseCase

TOKEN = "123456:TEST_TOKEN_NOT_REAL"


def sign(body: bytes, token=TOKEN) -> str:
    return hmac.new(hashlib.sha256(token.encode()).digest(), body, hashlib.sha256).hexdigest()


class FakeBot:
    def __init__(self):
        self.invoices, self.refunds, self.fail_refund = [], [], False

    async def send_invoice(self, **kw):
        self.invoices.append(kw)

    async def refund_star_payment(self, user_id, telegram_payment_charge_id):
        if self.fail_refund:
            raise RuntimeError("CHARGE_ALREADY_REFUNDED")
        self.refunds.append((user_id, telegram_payment_charge_id))


class StarsTests(BaseCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        e = self.env
        e.bot = FakeBot()
        e.stars = StarsProvider(e.bot, e.plans, e.orders, e.users, e.fulfillment)
        await e.plans.set_stars_price("m1", 90)
        self.user = await self.new_user(500)
        self.order = await e.orders.create_order(self.user["id"], "m1", "STARS")

    def sp(self, charge="CH-1", amount=90, currency="XTR", payload=None):
        return SimpleNamespace(invoice_payload=payload or self.order["public_id"], total_amount=amount,
                               currency=currency, telegram_payment_charge_id=charge,
                               provider_payment_charge_id="")

    async def test_availability_depends_on_configured_price(self):
        self.assertTrue(await self.env.stars.available_for("m1"))
        self.assertFalse(await self.env.stars.available_for("m3"))

    async def test_invoice_is_xtr_single_price(self):
        try:
            import aiogram.types  # noqa: F401
        except ImportError:        # в окружении без aiogram подставляем минимальный LabeledPrice
            import sys, types
            sys.modules.setdefault("aiogram", types.ModuleType("aiogram"))
            mod = types.ModuleType("aiogram.types")
            mod.LabeledPrice = lambda label, amount: SimpleNamespace(label=label, amount=amount)
            sys.modules["aiogram.types"] = mod
        await self.env.stars.start(self.order, self.user)
        inv = self.env.bot.invoices[0]
        self.assertEqual(inv["currency"], "XTR")
        self.assertEqual(inv["payload"], self.order["public_id"])
        self.assertEqual(len(inv["prices"]), 1)
        self.assertEqual(inv["prices"][0].amount, 90)
        self.assertNotIn("provider_token", inv)

    async def test_pre_checkout_validation(self):
        v = self.env.stars.validate_pre_checkout
        pid = self.order["public_id"]
        self.assertEqual(await v(500, pid, "XTR", 90), (True, ""))
        self.assertFalse((await v(501, pid, "XTR", 90))[0])        # чужой пользователь
        self.assertFalse((await v(500, pid, "XTR", 89))[0])        # неверная сумма
        self.assertFalse((await v(500, pid, "USD", 90))[0])        # неверная валюта
        self.assertFalse((await v(500, "FX-00000000", "XTR", 90))[0])
        self.env.settings  # noqa
        await self.env.users.set_blocked(self.user["id"], True)
        self.assertFalse((await v(500, pid, "XTR", 90))[0])

    async def test_pre_checkout_rejects_expired_order(self):
        from utils import clock
        clock.advance(3 * 3600)
        self.assertFalse((await self.env.stars.validate_pre_checkout(500, self.order["public_id"], "XTR", 90))[0])

    async def test_successful_payment_activates_once(self):
        self.assertIsNone(await self.env.subs.get(self.user["id"]))
        self.assertEqual(await self.env.stars.handle_successful_payment(500, self.sp()), "ok")
        sub = await self.env.subs.get(self.user["id"])
        self.assertEqual(sub["ends_at"], T0 + 30 * DAY)
        pay = await self.env.orders.payment_for_order(self.order["id"])
        self.assertEqual(pay["external_id"], "CH-1")                       # charge id сохранён
        # повторная доставка того же события
        self.assertEqual(await self.env.stars.handle_successful_payment(500, self.sp()), "duplicate")
        self.assertEqual((await self.env.subs.get(self.user["id"]))["ends_at"], T0 + 30 * DAY)

    async def test_wrong_amount_or_user_does_not_activate(self):
        await self.env.stars.handle_successful_payment(500, self.sp(charge="X", amount=10))
        await self.env.stars.handle_successful_payment(999, self.sp(charge="Y"))
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

    async def test_refund_rolls_back_subscription(self):
        await self.env.stars.handle_successful_payment(500, self.sp())
        order = await self.env.orders.get(self.order["id"])
        ok, _ = await self.env.stars.refund(order)
        self.assertTrue(ok)
        self.assertEqual(self.env.bot.refunds, [(500, "CH-1")])
        self.assertEqual((await self.env.orders.get(order["id"]))["status"], "REFUNDED")
        sub = await self.env.subs.view(self.user["id"])
        self.assertFalse(sub["is_active"])
        ok2, _ = await self.env.stars.refund(await self.env.orders.get(order["id"]))
        self.assertFalse(ok2)                                              # повторный возврат невозможен

    async def test_refund_failure_keeps_order_paid(self):
        await self.env.stars.handle_successful_payment(500, self.sp())
        self.env.bot.fail_refund = True
        ok, _ = await self.env.stars.refund(await self.env.orders.get(self.order["id"]))
        self.assertFalse(ok)
        self.assertEqual((await self.env.orders.get(self.order["id"]))["status"], "PAID")


class FakeHttp:
    def __init__(self):
        self.responses, self.calls = [], []

    async def request(self, method, url, **kw):
        self.calls.append((method, url, kw))
        return self.responses.pop(0)


class CryptoTests(BaseCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        e = self.env
        e.http = FakeHttp()
        e.crypto = CryptoBotProvider(TOKEN, "test", "USDT,TON", e.orders, e.users, e.fulfillment, http=e.http)
        self.user = await self.new_user(600)
        self.order = await e.orders.create_order(self.user["id"], "m1", "CRYPTOBOT")

    def invoice(self, status="paid", amount="100.00", fiat="RUB", inv_id=777):
        return {"invoice_id": inv_id, "status": status, "payload": self.order["public_id"],
                "currency_type": "fiat", "fiat": fiat, "amount": amount, "paid_asset": "USDT",
                "paid_amount": "1.1"}

    def update(self, **kw):
        return json.dumps({"update_id": 1, "update_type": "invoice_paid", "request_date": "2026-01-01T00:00:00Z",
                           "payload": self.invoice(**kw)}).encode()

    def test_signature(self):
        body = b'{"a":1}'
        self.assertTrue(verify_signature(TOKEN, body, sign(body)))
        self.assertFalse(verify_signature(TOKEN, body, sign(b"other")))
        self.assertFalse(verify_signature(TOKEN, body, ""))
        self.assertFalse(verify_signature("", body, sign(body)))

    async def test_create_invoice_uses_documented_params(self):
        self.env.http.responses.append((200, {"ok": True, "result": {
            "invoice_id": 777, "bot_invoice_url": "https://t.me/CryptoTestnetBot?start=IVx"}}, ""))
        st = await self.env.crypto.start(self.order, self.user)
        method, url, kw = self.env.http.calls[0]
        self.assertEqual(url, "https://testnet-pay.crypt.bot/api/createInvoice")
        self.assertEqual(kw["headers"], {"Crypto-Pay-API-Token": TOKEN})
        p = kw["json_body"]
        self.assertEqual((p["currency_type"], p["fiat"], p["amount"], p["payload"]),
                         ("fiat", "RUB", "100.00", self.order["public_id"]))
        self.assertEqual(st.external_id, "777")
        self.assertTrue(st.url.startswith("https://t.me/"))

    async def test_webhook_rejects_bad_signature(self):
        body = self.update()
        self.assertEqual((await self.env.crypto.handle_webhook(body, "deadbeef"))[0], 403)
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

    async def test_webhook_pays_once_and_is_idempotent(self):
        await self.env.orders.set_external(self.order["id"], "777", None)
        body = self.update()
        self.assertEqual(await self.env.crypto.handle_webhook(body, sign(body)), (200, "ok"))
        end = (await self.env.subs.get(self.user["id"]))["ends_at"]
        self.assertEqual(end, T0 + 30 * DAY)
        for _ in range(3):                                               # повторные уведомления
            self.assertEqual((await self.env.crypto.handle_webhook(body, sign(body)))[0], 200)
        self.assertEqual((await self.env.subs.get(self.user["id"]))["ends_at"], end)
        n = await self.env.db.fetchone("SELECT COUNT(*) c FROM payments WHERE status='PAID'")
        self.assertEqual(n["c"], 1)

    async def test_webhook_ignores_unpaid_and_mismatching_invoices(self):
        for kw in ({"status": "active"}, {"amount": "10.00"}, {"fiat": "USD"}):
            body = self.update(**kw)
            await self.env.crypto.handle_webhook(body, sign(body))
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

    async def test_poll_marks_paid_and_expired(self):
        await self.env.orders.set_external(self.order["id"], "777", None)
        self.env.http.responses.append((200, {"ok": True, "result": {"items": [self.invoice()]}}, ""))
        await self.env.crypto.poll_pending()
        self.assertEqual((await self.env.orders.get(self.order["id"]))["status"], "PAID")
        o2 = await self.env.orders.create_order(self.user["id"], "m3", "CRYPTOBOT")
        await self.env.orders.set_external(o2["id"], "888", None)
        inv = dict(self.invoice(status="expired", inv_id=888), payload=o2["public_id"])
        self.env.http.responses.append((200, {"ok": True, "result": [inv]}, ""))   # старый формат: список
        await self.env.crypto.poll_pending()
        self.assertEqual((await self.env.orders.get(o2["id"]))["status"], "EXPIRED")

    async def test_api_error_is_handled(self):
        self.env.http.responses.append((200, {"ok": False, "error": {"code": 400, "name": "BAD"}}, ""))
        from payments.cryptobot import CryptoPayError
        with self.assertRaises(CryptoPayError):
            await self.env.crypto.start(self.order, self.user)


class DonateAlertsTests(BaseCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        e = self.env
        self.tmp = tempfile.TemporaryDirectory()
        e.da = DonateAlertsProvider("https://www.donationalerts.com/r/test", "cid", "secret",
                                    str(Path(self.tmp.name) / "tok.json"), e.orders, e.users, e.fulfillment,
                                    http=FakeHttp())
        self.user = await self.new_user(700)
        self.order = await e.orders.create_order(self.user["id"], "m1", "DONATEALERTS")

    async def asyncTearDown(self):
        self.tmp.cleanup()
        await super().asyncTearDown()

    def donation(self, did=1, msg=None, amount=100, currency="RUB"):
        return {"id": did, "message": msg if msg is not None else f"оплата {self.order['public_id'].lower()}",
                "amount": amount, "currency": currency, "username": "payer"}

    def test_extract_code(self):
        self.assertEqual(extract_code("pay fx-0a1b2c3d thanks"), "FX-0A1B2C3D")
        self.assertIsNone(extract_code("no code"))
        self.assertIsNone(extract_code(None))

    async def test_match_rules(self):
        by = {self.order["public_id"]: self.order}
        self.assertIsNotNone(match_donation(self.donation(), by))
        self.assertIsNotNone(match_donation(self.donation(amount=250.5), by))
        self.assertIsNone(match_donation(self.donation(amount=99.99), by))
        self.assertIsNone(match_donation(self.donation(currency="USD"), by))
        self.assertIsNone(match_donation(self.donation(msg="без кода"), by))
        self.assertIsNone(match_donation(self.donation(msg="FX-DEADBEEF"), by))

    async def test_auto_confirmation_and_replay(self):
        self.assertEqual(await self.env.da.process_donations([self.donation(did=11)]), 1)
        end = (await self.env.subs.get(self.user["id"]))["ends_at"]
        self.assertEqual(await self.env.da.process_donations([self.donation(did=11)]), 0)
        # другой донат с тем же кодом уже не засчитывается (заказ оплачен)
        await self.env.da.process_donations([self.donation(did=12)])
        self.assertEqual((await self.env.subs.get(self.user["id"]))["ends_at"], end)

    async def test_underpayment_not_confirmed(self):
        await self.env.da.process_donations([self.donation(did=1, amount=50)])
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

    async def test_api_not_ready_without_token_file(self):
        self.assertFalse(self.env.da.api_ready)
        st = await self.env.da.start(self.order, self.user)
        self.assertTrue(st.show_paid_button and not st.show_check)
        self.assertIn(self.order["public_id"], st.text)
        self.assertEqual(await self.env.da.fetch_donations(), [])

    async def test_manual_confirmation_by_admin_is_idempotent(self):
        out = await self.env.da.manual_confirm(self.order["id"], admin_tg_id=1)
        self.assertEqual(out.status, "ok")
        out2 = await self.env.da.manual_confirm(self.order["id"], admin_tg_id=1)
        self.assertEqual(out2.status, "duplicate")
        self.assertEqual((await self.env.subs.get(self.user["id"]))["ends_at"], T0 + 30 * DAY)

    async def test_fetch_uses_bearer_and_documented_endpoint(self):
        import json, time
        Path(self.env.da.token_file).write_text(json.dumps(
            {"access_token": "AT", "refresh_token": "RT", "expires_at": int(time.time()) + 3600}))
        self.env.da.http.responses.append((200, {"data": [self.donation(did=5)]}, ""))
        self.env.da.http.responses.append((200, {"data": []}, ""))
        got = await self.env.da.fetch_donations()
        self.assertEqual(len(got), 1)
        m, url, kw = self.env.da.http.calls[0]
        self.assertEqual(url, "https://www.donationalerts.com/api/v1/alerts/donations")
        self.assertEqual(kw["headers"], {"Authorization": "Bearer AT"})


class PaymentSafety(BaseCase):
    async def test_cross_provider_and_amount_mismatch_rejected(self):
        u = await self.new_user()
        o = await self.env.orders.create_order(u["id"], "m1", "CRYPTOBOT")
        f = self.env.fulfillment
        r1 = await f.confirm(o["id"], source="STARS", external_id="s1", amount=100, currency="RUB")
        r2 = await f.confirm(o["id"], source="CRYPTOBOT", external_id="c1", amount=50, currency="RUB")
        r3 = await f.confirm(o["id"], source="CRYPTOBOT", external_id="c2", amount=100, currency="XTR")
        self.assertEqual([r1.status, r2.status, r3.status], ["rejected"] * 3)
        self.assertIsNone(await self.env.subs.get(u["id"]))
        self.assertTrue(self.env.notifier.admin)

    async def test_second_payment_for_paid_order_flagged_not_extended(self):
        u = await self.new_user()
        o, _ = await self.paid_order(u, "m1", ext="a")
        end = (await self.env.subs.get(u["id"]))["ends_at"]
        r = await self.env.fulfillment.confirm(o["id"], source="CRYPTOBOT", external_id="b",
                                               amount=100, currency="RUB")
        self.assertEqual(r.status, "already_paid")
        self.assertEqual((await self.env.subs.get(u["id"]))["ends_at"], end)
