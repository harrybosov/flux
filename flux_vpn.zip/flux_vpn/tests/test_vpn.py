"""Интеграция с 3X-UI: адаптер на фейковой панели, ошибки API, отсутствие дубликатов, ссылки."""
import json
from types import SimpleNamespace

from tests.helpers import DAY, T0, BaseCase, FakePanel, reality_inbound
from vpn import links
from vpn.base import PanelAuthError, PanelConnectionError, PanelError, UnsupportedProtocol
from vpn.nodes import NodeRegistry
from vpn.subscriptions import VpnManager, client_email
from vpn.xui_adapter import XuiAdapter

BASE = "https://panel.test/secret"


def node(key="DE"):
    return SimpleNamespace(key=key, base_url=BASE, username="admin", password="pw", public_host="de.test",
                           verify_ssl=True, country=key, inbound_ids=[1])


def make_adapter(panel):
    return XuiAdapter(node(), transport=panel)


class XuiAdapterTests(BaseCase):
    def setUp(self):
        self.panel = FakePanel(BASE, {1: reality_inbound(1)})
        self.adapter = make_adapter(self.panel)

    async def test_creates_client_with_expiry_and_flow(self):
        st = await self.adapter.ensure_client(1, "flux1-de1", None, T0 + DAY, True, comment="c")
        self.assertTrue(st.created)
        c = self.panel.inbounds[1]["settings"]["clients"][0]
        self.assertEqual((c["email"], c["expiryTime"], c["enable"]), ("flux1-de1", (T0 + DAY) * 1000, True))
        self.assertEqual(c["flow"], "xtls-rprx-vision")
        self.assertEqual(st.secret, c["id"])
        self.assertEqual(st.label, "VLESS + REALITY")

    async def test_second_call_updates_and_never_duplicates(self):
        a = await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)
        b = await self.adapter.ensure_client(1, "e1", a.secret, T0 + 5 * DAY, True)
        self.assertFalse(b.created)
        self.assertEqual(len(self.panel.inbounds[1]["settings"]["clients"]), 1)
        self.assertEqual(self.panel.inbounds[1]["settings"]["clients"][0]["expiryTime"], (T0 + 5 * DAY) * 1000)
        self.assertEqual(a.secret, b.secret)

    async def test_disable_expired(self):
        await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)
        st = await self.adapter.ensure_client(1, "e1", None, T0 + DAY, False)
        self.assertFalse(st.enabled)
        self.assertFalse(self.panel.inbounds[1]["settings"]["clients"][0]["enable"])

    async def test_relogin_when_session_expires(self):
        await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)
        self.panel.expire_session()                          # 3X-UI отвечает 404 без сессии
        st = await self.adapter.ensure_client(1, "e1", None, T0 + 2 * DAY, True)
        self.assertEqual(st.expiry_ts, T0 + 2 * DAY)
        self.assertGreaterEqual(sum(1 for m, p in self.panel.calls if p == "/login"), 2)

    async def test_bad_credentials(self):
        self.panel.login_ok = False
        with self.assertRaises(PanelAuthError):
            await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)

    async def test_connection_error(self):
        self.panel.conn_error = True
        with self.assertRaises(PanelConnectionError):
            await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)

    async def test_panel_rejects_request(self):
        await self.adapter.ensure_client(1, "e0", None, T0 + DAY, True)
        self.panel.reject_msg = "inbound is busy"
        with self.assertRaises(PanelError) as cm:
            await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)
        self.assertIn("inbound is busy", str(cm.exception))

    async def test_missing_inbound(self):
        with self.assertRaises(PanelError):
            await self.adapter.ensure_client(99, "e1", None, T0 + DAY, True)

    async def test_silent_noop_update_is_detected(self):
        await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)
        self.panel.ignore_updates = True                    # панель отвечает success, но не сохраняет
        with self.assertRaises(PanelError):
            await self.adapter.ensure_client(1, "e1", None, T0 + 9 * DAY, True)

    async def test_unsupported_protocol(self):
        self.panel.inbounds[1] = reality_inbound(1, protocol="wireguard")
        with self.assertRaises(UnsupportedProtocol):
            await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)

    async def test_trojan_and_vmess_keys(self):
        ib = reality_inbound(1, protocol="trojan")
        ib["stream"] = {"network": "tcp", "security": "tls", "tlsSettings": {"serverName": "t.example"}}
        self.panel.inbounds[1] = ib
        a = await self.adapter.ensure_client(1, "t1", None, T0 + DAY, True)
        c = ib["settings"]["clients"][0]
        self.assertEqual(c["password"], a.secret)
        await self.adapter.ensure_client(1, "t1", a.secret, T0 + 2 * DAY, True)   # update по password
        self.assertEqual(len(ib["settings"]["clients"]), 1)

    async def test_build_link_vless_reality(self):
        st = await self.adapter.ensure_client(1, "e1", None, T0 + DAY, True)
        info = await self.adapter.build_link(1, "e1", st.secret, "FLUX Germany 1")
        link = info.link
        self.assertTrue(link.startswith(f"vless://{st.secret}@de.test:443?"))
        for part in ("security=reality", "pbk=PUBKEY", "sid=ab12", "sni=www.example.com",
                     "flow=xtls-rprx-vision", "fp=chrome", "encryption=none"):
            self.assertIn(part, link)
        self.assertTrue(link.endswith("#FLUX%20Germany%201"))


class LinkTests(BaseCase):
    def test_vmess_ws_tls(self):
        ib = {"protocol": "vmess", "port": 8443, "settings": "{}",
              "streamSettings": json.dumps({"network": "ws", "security": "tls",
                                            "wsSettings": {"path": "/ws", "headers": {"Host": "h.example"}},
                                            "tlsSettings": {"serverName": "h.example"}})}
        link = links.build_link(ib, "x.test", {"id": "UUID"}, "R")
        self.assertTrue(link.startswith("vmess://"))
        import base64
        obj = json.loads(base64.b64decode(link[8:]))
        self.assertEqual((obj["add"], obj["port"], obj["net"], obj["path"], obj["tls"]),
                         ("x.test", "8443", "ws", "/ws", "tls"))

    def test_protocol_labels(self):
        self.assertEqual(links.protocol_label({"protocol": "vless", "streamSettings": json.dumps(
            {"network": "tcp", "security": "tls"})}), "VLESS + TLS")
        self.assertEqual(links.protocol_label({"protocol": "trojan", "streamSettings": "{}"}), "Trojan")

    def test_unknown_protocol(self):
        with self.assertRaises(UnsupportedProtocol):
            links.build_link({"protocol": "hysteria2", "port": 1}, "h", {}, "r")


class VpnManagerTests(BaseCase):
    async def test_six_clients_no_duplicates_on_repeat_sync(self):
        u = await self.new_user()
        await self.paid_order(u)
        for _ in range(3):
            self.assertTrue((await self.env.vpn.sync_user(u["id"])).ok)
        for a in self.env.adapters.values():
            self.assertEqual(len(a.clients), 3)
        n = await self.env.db.fetchone("SELECT COUNT(*) c FROM vpn_clients WHERE user_id=?", (u["id"],))
        self.assertEqual(n["c"], 6)
        emails = {r["email"] for r in await self.env.db.fetchall("SELECT email FROM vpn_clients")}
        self.assertIn(client_email(u["tg_id"], "DE", 1), emails)

    async def test_secret_is_stable_across_syncs(self):
        u = await self.new_user()
        await self.paid_order(u)
        before = {r["email"]: r["secret"] for r in await self.env.db.fetchall("SELECT * FROM vpn_clients")}
        await self.paid_order(u, "m3", ext="z")
        after = {r["email"]: r["secret"] for r in await self.env.db.fetchall("SELECT * FROM vpn_clients")}
        self.assertEqual(before, after)

    async def test_panel_failure_keeps_dirty_and_retry_succeeds(self):
        u = await self.new_user()
        self.env.adapters["US"].fail = True
        _, out = await self.paid_order(u)
        self.assertEqual(out.status, "ok")                         # оплата принята, подписка есть
        sub = await self.env.subs.get(u["id"])
        self.assertEqual(sub["vpn_dirty"], 1)
        self.assertIn("US", sub["vpn_error"])
        self.assertTrue(self.env.notifier.admin)
        self.assertEqual(await self.env.vpn.count_clients(u["id"]), 3)   # Германия выдана
        self.env.adapters["US"].fail = False
        self.assertEqual([s["user_id"] for s in await self.env.subs.dirty()], [u["id"]])
        self.assertTrue((await self.env.vpn.sync_user(u["id"])).ok)
        self.assertEqual((await self.env.subs.get(u["id"]))["vpn_dirty"], 0)
        self.assertEqual(await self.env.vpn.count_clients(u["id"]), 6)

    async def test_users_see_only_their_own_connections(self):
        a, b = await self.new_user(1), await self.new_user(2)
        await self.paid_order(a, ext="1")
        self.assertEqual(len(await self.env.vpn.connections(a["id"])), 6)
        self.assertEqual(await self.env.vpn.connections(b["id"]), [])

    async def test_views_are_ordered_and_marked_placeholder(self):
        u = await self.new_user()
        await self.paid_order(u)
        views = await self.env.vpn.connections(u["id"])
        self.assertEqual([(v.country, v.position) for v in views],
                         [("DE", 1), ("DE", 2), ("DE", 3), ("US", 1), ("US", 2), ("US", 3)])
        self.assertTrue(all(v.is_placeholder and v.link.startswith("flux-demo://NOT-A-REAL-CONFIG") for v in views))

    async def test_registry_sync_db_is_idempotent(self):
        await self.env.registry.sync_db()
        await self.env.registry.sync_db()
        n = await self.env.db.fetchone("SELECT COUNT(*) c FROM vpn_inbounds")
        self.assertEqual(n["c"], 6)
