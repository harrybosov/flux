"""DonateAlerts (DonationAlerts).

Что умеет официальный API (https://www.donationalerts.com/apidoc): OAuth2 + ЧТЕНИЕ списка донатов
(GET /api/v1/alerts/donations, scope oauth-donation-index). Создания индивидуальных счетов/платёжных
ссылок и webhook'ов об оплате в API НЕТ.

Поэтому схема такая:
  1. Заказ получает уникальный код FX-XXXXXXXX. Пользователь переводит донат на вашу страницу и ОБЯЗАТЕЛЬНО
     пишет код в поле «Сообщение».
  2. Бот опрашивает список донатов и сопоставляет: код в сообщении + валюта RUB + сумма ≥ цены заказа.
     Донат с тем же ID повторно не обрабатывается (UNIQUE(provider, external_id)).
  3. Если OAuth не настроен — ручное подтверждение администратором. Скриншоту пользователя не доверяем."""
from __future__ import annotations

import json
import logging
import math
import re
import time
from pathlib import Path

from models import CURRENCY_RUB, OrderStatus, Provider
from payments.base import PaymentProvider, PaymentStart
from utils import clock
from utils.http import HttpClient, HttpError

log = logging.getLogger(__name__)
API = "https://www.donationalerts.com/api/v1/alerts/donations"
TOKEN_URL = "https://www.donationalerts.com/oauth/token"
CODE_RE = re.compile(r"FX-[0-9A-F]{8}", re.IGNORECASE)


def extract_code(message: str | None) -> str | None:
    m = CODE_RE.search(message or "")
    return m.group(0).upper() if m else None


def match_donation(donation: dict, orders_by_public: dict[str, dict]) -> tuple[dict, int] | None:
    """Чистая функция сопоставления. Возвращает (заказ, зачтённая сумма) или None."""
    code = extract_code(donation.get("message"))
    order = orders_by_public.get(code or "")
    if not order:
        return None
    if str(donation.get("currency", "")).upper() != CURRENCY_RUB:
        return None
    try:
        amount = math.floor(float(donation.get("amount")))
    except (TypeError, ValueError):
        return None
    if amount < order["amount"]:
        return None
    return order, amount


class DonateAlertsProvider(PaymentProvider):
    code = Provider.DONATEALERTS
    title = "💳 DonateAlerts"

    def __init__(self, donate_url: str, client_id: str, client_secret: str, token_file: str,
                 orders, users, fulfillment, http: HttpClient | None = None):
        self.donate_url, self.client_id, self.client_secret = donate_url, client_id, client_secret
        self.token_file = Path(token_file)
        self.orders, self.users, self.fulfillment = orders, users, fulfillment
        self.http = http or HttpClient()
        self._warned = False

    def is_configured(self) -> bool:
        return bool(self.donate_url)

    @property
    def api_ready(self) -> bool:
        return bool(self.client_id and self.client_secret and self.token_file.exists())

    # ---------- токены ----------
    def _load_token(self) -> dict | None:
        try:
            return json.loads(self.token_file.read_text())
        except (OSError, ValueError):
            return None

    def _save_token(self, data: dict) -> None:
        self.token_file.parent.mkdir(parents=True, exist_ok=True)
        self.token_file.write_text(json.dumps(data))
        try:
            self.token_file.chmod(0o600)
        except OSError:
            pass

    async def _access_token(self) -> str | None:
        tok = self._load_token()
        if not tok or not tok.get("access_token"):
            return None
        if tok.get("expires_at", 0) - 120 > time.time():
            return tok["access_token"]
        if not tok.get("refresh_token"):
            return None
        try:
            status, body, _ = await self.http.request("POST", TOKEN_URL, form={
                "grant_type": "refresh_token", "refresh_token": tok["refresh_token"],
                "client_id": self.client_id, "client_secret": self.client_secret,
                "scope": "oauth-donation-index"})
        except HttpError as e:
            log.warning("DonateAlerts refresh failed: %s", e)
            return None
        if not isinstance(body, dict) or "access_token" not in body:
            log.error("DonateAlerts: не удалось обновить токен (HTTP %s)", status)
            return None
        tok = {"access_token": body["access_token"],
               "refresh_token": body.get("refresh_token", tok["refresh_token"]),
               "expires_at": int(time.time()) + int(body.get("expires_in", 3600))}
        self._save_token(tok)
        return tok["access_token"]

    async def fetch_donations(self, pages: int = 2) -> list[dict]:
        token = await self._access_token()
        if not token:
            return []
        out: list[dict] = []
        for page in range(1, pages + 1):
            try:
                status, body, _ = await self.http.request(
                    "GET", API, headers={"Authorization": f"Bearer {token}"}, params={"page": page})
            except HttpError as e:
                log.warning("DonateAlerts fetch failed: %s", e)
                break
            if status != 200 or not isinstance(body, dict):
                log.warning("DonateAlerts fetch: HTTP %s", status)
                break
            data = body.get("data") or []
            out += data
            if not data:
                break
        return out

    # ---------- сценарий оплаты ----------
    async def start(self, order: dict, user: dict) -> PaymentStart:
        auto = self.api_ready
        text = (
            f"💳 <b>Оплата через DonateAlerts</b>\n\n"
            f"1. Откройте страницу доната (кнопка ниже).\n"
            f"2. Сумма: <b>не меньше {order['amount']} ₽</b>, валюта — рубли.\n"
            f"3. В поле «Сообщение» впишите код заказа: <code>{order['public_id']}</code> — "
            f"<b>без него оплату не засчитать</b>.\n\n"
            + ("После перевода бот найдёт платёж автоматически (обычно до минуты) — можно нажать «🔄 Проверить оплату»."
               if auto else
               "После перевода нажмите «Я оплатил(а)» — администратор сверит поступление и подтвердит заказ. "
               "Скриншоты не принимаются как подтверждение."))
        return PaymentStart(text=text, url=self.donate_url, external_id=None,
                            show_check=auto, show_paid_button=True)

    async def _open_orders(self) -> dict[str, dict]:
        since = clock.now() - 3 * 86400
        rows = await self.orders.db.fetchall(
            "SELECT * FROM orders WHERE provider=? AND status IN (?,?) AND created_at>?",
            (Provider.DONATEALERTS, OrderStatus.PENDING, OrderStatus.EXPIRED, since))
        return {r["public_id"]: r for r in rows}

    async def process_donations(self, donations: list[dict]) -> int:
        """Сопоставляет донаты с открытыми заказами и подтверждает оплату. Возвращает число принятых."""
        open_orders = await self._open_orders()
        if not open_orders:
            return 0
        accepted = 0
        for d in donations:
            hit = match_donation(d, open_orders)
            if not hit or d.get("id") is None:
                continue
            order, amount = hit
            out = await self.fulfillment.confirm(
                order["id"], source=Provider.DONATEALERTS, external_id=str(d["id"]), amount=amount,
                currency=CURRENCY_RUB, note=f"donation by {str(d.get('username', ''))[:40]}")
            if out.status == "ok":
                accepted += 1
                open_orders.pop(order["public_id"], None)
        return accepted

    async def poll_pending(self) -> None:
        if not self.is_configured():
            return
        if not self.api_ready:
            if not self._warned:
                log.info("DonateAlerts: API не настроен — работает только ручное подтверждение")
                self._warned = True
            return
        if not await self._open_orders():
            return
        await self.process_donations(await self.fetch_donations())

    async def check(self, order: dict) -> bool:
        if not self.api_ready:
            return False
        before = (await self.orders.get(order["id"]))["status"]
        await self.process_donations(await self.fetch_donations())
        after = (await self.orders.get(order["id"]))["status"]
        return before != OrderStatus.PAID and after == OrderStatus.PAID

    async def manual_confirm(self, order_id: int, admin_tg_id: int):
        """Ручное подтверждение администратором (после сверки с кабинетом DonationAlerts)."""
        order = await self.orders.get(order_id)
        if not order or order["provider"] != Provider.DONATEALERTS:
            return None
        return await self.fulfillment.confirm(
            order_id, source=Provider.MANUAL, external_id=f"manual:{order['public_id']}",
            amount=order["amount"], currency=order["currency"], note=f"confirmed by admin {admin_tg_id}")
