"""CryptoBot — Crypto Pay API (https://help.crypt.bot/crypto-pay-api).
Используются только документированные методы: createInvoice, getInvoices; webhook invoice_paid.
Цена задаётся в RUB (currency_type=fiat), оплата — в одном из accepted_assets."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging

from models import CURRENCY_RUB, OrderStatus, Provider
from payments.base import PaymentProvider, PaymentStart
from utils import clock
from utils.http import HttpClient, HttpError

log = logging.getLogger(__name__)
MAIN = "https://pay.crypt.bot/api"
TEST = "https://testnet-pay.crypt.bot/api"


class CryptoPayError(Exception):
    pass


def verify_signature(token: str, raw_body: bytes, signature: str) -> bool:
    """HMAC-SHA256(body), ключ = SHA256(token); заголовок `crypto-pay-api-signature` (hex)."""
    if not token or not signature:
        return False
    key = hashlib.sha256(token.encode()).digest()
    expected = hmac.new(key, raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature.strip().lower())


def _items(result) -> list[dict]:
    if isinstance(result, list):
        return result
    if isinstance(result, dict):
        return result.get("items", []) or []
    return []


class CryptoBotProvider(PaymentProvider):
    code = Provider.CRYPTOBOT
    title = "🪙 CryptoBot"

    def __init__(self, token: str, network: str, assets: str, orders, users, fulfillment,
                 bot_username_getter=None, http: HttpClient | None = None):
        self.token, self.assets = token, assets
        self.base = TEST if network == "test" else MAIN
        self.orders, self.users, self.fulfillment = orders, users, fulfillment
        self._bot_username = bot_username_getter
        self.http = http or HttpClient()

    def is_configured(self) -> bool:
        return bool(self.token)

    async def _api(self, method: str, params: dict | None = None, *, post: bool = True):
        headers = {"Crypto-Pay-API-Token": self.token}
        try:
            if post:
                status, body, _ = await self.http.request("POST", f"{self.base}/{method}", headers=headers,
                                                          json_body=params or {})
            else:
                status, body, _ = await self.http.request("GET", f"{self.base}/{method}", headers=headers,
                                                          params=params or {})
        except HttpError as e:
            raise CryptoPayError(f"сеть: {e}") from e
        if not isinstance(body, dict) or not body.get("ok"):
            err = body.get("error") if isinstance(body, dict) else f"HTTP {status}"
            raise CryptoPayError(f"{method}: {err}")
        return body.get("result")

    async def start(self, order: dict, user: dict) -> PaymentStart:
        ttl = max(60, min(order["expires_at"] - clock.now(), 2678400))   # допустимо 1..2678400 сек
        params = {
            "currency_type": "fiat", "fiat": CURRENCY_RUB, "amount": f"{order['amount']:.2f}",
            "accepted_assets": self.assets,
            "description": f"FLUX VPN — {order['plan_name']} ({order['public_id']})"[:1000],
            "payload": order["public_id"], "expires_in": ttl, "allow_comments": False,
        }
        if self._bot_username:
            try:
                params.update(paid_btn_name="openBot", paid_btn_url=f"https://t.me/{await self._bot_username()}")
            except Exception:  # noqa: BLE001
                pass
        inv = await self._api("createInvoice", params)
        url = inv.get("bot_invoice_url") or inv.get("pay_url")
        return PaymentStart(
            text=(f"🪙 Счёт на <b>{order['amount']} ₽</b> создан. Оплатить можно в одной из криптовалют: "
                  f"{self.assets.replace(',', ', ')}. Счёт действителен {ttl // 60} мин."),
            url=url, external_id=str(inv["invoice_id"]), show_check=True)

    # ---------- обработка инвойса (webhook и опрос) ----------
    async def process_invoice(self, invoice: dict):
        """Возвращает PaymentOutcome или None, если инвойс не оплачен / не наш."""
        if invoice.get("status") != "paid":
            return None
        order = await self.orders.get_by_public(str(invoice.get("payload") or ""))
        if not order or order["provider"] != Provider.CRYPTOBOT:
            log.warning("CryptoBot: инвойс %s без нашего заказа", invoice.get("invoice_id"))
            return None
        inv_id = str(invoice.get("invoice_id"))
        if order["external_id"] and order["external_id"] != inv_id:
            log.error("CryptoBot: invoice_id не совпадает с заказом %s", order["public_id"])
            return None
        try:
            same_price = abs(float(invoice.get("amount", "0")) - order["amount"]) < 0.01
        except (TypeError, ValueError):
            same_price = False
        if invoice.get("currency_type") != "fiat" or invoice.get("fiat") != CURRENCY_RUB or not same_price:
            log.error("CryptoBot: параметры инвойса не совпадают с заказом %s", order["public_id"])
            await self.fulfillment.notifier.notify_admins(
                f"⚠️ CryptoBot: инвойс {inv_id} оплачен, но не совпадает с заказом {order['public_id']}")
            return None
        note = f"paid {invoice.get('paid_amount')} {invoice.get('paid_asset')}"
        return await self.fulfillment.confirm(order["id"], source=Provider.CRYPTOBOT, external_id=inv_id,
                                              amount=order["amount"], currency=CURRENCY_RUB, note=note)

    async def handle_webhook(self, raw_body: bytes, signature: str) -> tuple[int, str]:
        if not verify_signature(self.token, raw_body, signature):
            return 403, "bad signature"
        try:
            update = json.loads(raw_body)
        except ValueError:
            return 400, "bad json"
        if update.get("update_type") != "invoice_paid":
            return 200, "ignored"
        try:
            await self.process_invoice(update.get("payload") or {})
        except Exception:  # noqa: BLE001
            log.exception("CryptoBot webhook processing failed")
            return 500, "error"      # Crypto Pay повторит доставку; обработка идемпотентна
        return 200, "ok"

    # ---------- активная проверка ----------
    async def _fetch(self, ids: list[str]) -> list[dict]:
        res = await self._api("getInvoices", {"invoice_ids": ",".join(ids)}, post=False)
        return _items(res)

    async def _apply_status(self, order: dict, invoice: dict) -> bool:
        if invoice.get("status") == "paid":
            out = await self.process_invoice(invoice)
            return bool(out and out.status == "ok")
        if invoice.get("status") == "expired" and order["status"] == OrderStatus.PENDING:
            await self.orders.db.execute("UPDATE orders SET status=? WHERE id=? AND status=?",
                                         (OrderStatus.EXPIRED, order["id"], OrderStatus.PENDING))
        return False

    async def check(self, order: dict) -> bool:
        if not order.get("external_id"):
            return False
        try:
            items = await self._fetch([order["external_id"]])
        except CryptoPayError as e:
            log.warning("CryptoBot check failed: %s", e)
            return False
        for inv in items:
            if str(inv.get("invoice_id")) == order["external_id"]:
                return await self._apply_status(order, inv)
        return False

    async def poll_pending(self) -> None:
        if not self.is_configured():
            return
        pending = [o for o in await self.orders.pending_by_provider(Provider.CRYPTOBOT) if o["external_id"]]
        for i in range(0, len(pending), 100):
            chunk = pending[i:i + 100]
            try:
                items = await self._fetch([o["external_id"] for o in chunk])
            except CryptoPayError as e:
                log.warning("CryptoBot poll failed: %s", e)
                return
            by_id = {str(x.get("invoice_id")): x for x in items}
            for o in chunk:
                inv = by_id.get(o["external_id"])
                if inv:
                    await self._apply_status(o, inv)
