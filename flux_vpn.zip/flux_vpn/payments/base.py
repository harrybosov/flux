from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class PaymentStart:
    text: str                       # что показать пользователю (HTML)
    url: str | None = None          # кнопка «Оплатить»
    external_id: str | None = None  # ID счёта у провайдера
    show_check: bool = False        # показывать «🔄 Проверить оплату»
    show_paid_button: bool = False  # «Я оплатил(а)» (DonateAlerts)


class PaymentProvider(ABC):
    code: str = ""
    title: str = ""

    @abstractmethod
    def is_configured(self) -> bool: ...

    async def available_for(self, plan_id: str) -> bool:
        return self.is_configured()

    @abstractmethod
    async def start(self, order: dict, user: dict) -> PaymentStart: ...

    async def check(self, order: dict) -> bool:
        """Активная проверка заказа у провайдера. True, если оплата подтверждена в этот вызов."""
        return False

    async def poll_pending(self) -> None:
        """Фоновый опрос неоплаченных заказов (по умолчанию ничего)."""
        return None
