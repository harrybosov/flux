"""Клавиатуры. Цвета: синий — основные, зелёный — покупка, красный — возврат.
Нативные цвета кнопок (поле `style`) используются, только если установленная версия aiogram их поддерживает."""
from __future__ import annotations

from aiogram.types import CopyTextButton, InlineKeyboardButton, InlineKeyboardMarkup

from models import PROVIDER_TITLES
from utils import texts

_HAS_STYLE = "style" in InlineKeyboardButton.model_fields
PRIMARY, SUCCESS, DANGER = "primary", "success", "danger"


def btn(text: str, data: str | None = None, *, url: str | None = None, copy: str | None = None,
        style: str | None = PRIMARY) -> InlineKeyboardButton:
    kw: dict = {"text": text}
    if url:
        kw["url"] = url
    elif copy:
        kw["copy_text"] = CopyTextButton(text=copy)
    else:
        kw["callback_data"] = data
    if style and _HAS_STYLE:
        kw["style"] = style
    return InlineKeyboardButton(**kw)


def kb(rows: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back(data: str = "menu", text: str = "🔙 Назад") -> InlineKeyboardButton:
    return btn(text, data, style=DANGER)


def home() -> InlineKeyboardButton:
    return btn("🔙 Главное меню", "menu", style=DANGER)


def main_menu(is_admin: bool = False):
    rows = [
        [btn("🛒 Купить подписку", "shop", style=SUCCESS)],
        [btn("👤 Личный кабинет", "cabinet"), btn("🔑 Мои подключения", "conns")],
        [btn("🎁 Реферальная программа", "ref"), btn("🎟 Промокод", "promo")],
        [btn("🆘 Поддержка", "support")],
    ]
    if is_admin:
        rows.append([btn("🛠 Админ-панель", "adm")])
    return kb(rows)


def plans_kb(plans: list[dict]):
    rows = [[btn(f"{p['name']} — {p['price_rub']} ₽ · {texts.fmt_days(p['days'])}", f"plan:{p['id']}")]
            for p in plans]
    rows.append([home()])
    return kb(rows)


def plan_kb(plan_id: str, provider_codes: list[str]):
    rows = [[btn(PROVIDER_TITLES[c], f"pm:{plan_id}:{c}")] for c in provider_codes]
    rows.append([back("shop"), home()])
    return kb(rows)


def confirm_kb(plan_id: str, code: str):
    return kb([[btn("✅ Подтвердить и оплатить", f"buy:{plan_id}:{code}", style=SUCCESS)],
               [back(f"plan:{plan_id}"), home()]])


def pay_kb(order: dict, start) -> InlineKeyboardMarkup:
    rows = []
    if start.url:
        rows.append([btn("💳 Оплатить", url=start.url, style=SUCCESS)])
    if start.show_check:
        rows.append([btn("🔄 Проверить оплату", f"chk:{order['public_id']}")])
    if start.show_paid_button:
        rows.append([btn("✅ Я оплатил(а)", f"paid:{order['public_id']}", style=SUCCESS)])
    rows.append([btn("🚫 Отменить заказ", f"cancel:{order['public_id']}", style=DANGER)])
    rows.append([home()])
    return kb(rows)


def cabinet_kb(active: bool):
    rows = [[btn("🔄 Продлить подписку" if active else "🛒 Продлить / купить", "shop", style=SUCCESS)],
            [btn("🔑 Мои подключения", "conns"), btn("🧾 История платежей", "history")],
            [btn("🎁 Реферальная программа", "ref")], [home()]]
    return kb(rows)


def conns_kb(views):
    rows = [[btn(v.title + (f" · {v.protocol_label}" if v.protocol_label and v.protocol_label != "—" else ""),
                 f"conn:{v.inbound_id}")] for v in views]
    rows.append([btn("📋 Показать все ссылки", "conns_all")])
    rows.append([btn("📖 Как подключиться", "help")])
    rows.append([home()])
    return kb(rows)


def conn_kb(view):
    rows = []
    if view.link and len(view.link) <= 256:       # ограничение Telegram для copy_text
        rows.append([btn("📋 Копировать ссылку", copy=view.link)])
    if view.link:
        rows.append([btn("🔳 QR-код", f"qr:{view.inbound_id}")])
    rows.append([btn("📖 Инструкция", "help")])
    rows.append([back("conns", "🔙 К подключениям")])
    return kb(rows)
