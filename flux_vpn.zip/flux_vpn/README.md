# ⚡ FLUX VPN — Telegram-бот

Бот продаёт VPN-подписки: выдаёт **6 подключений одновременно** (🇩🇪 Germany 1–3, 🇺🇸 USA 1–3) через панели **3X-UI**,
принимает оплату через **Telegram Stars**, **CryptoBot** и **DonateAlerts**, ведёт личный кабинет, рефералов, промокоды и админ-панель.

Стек: Python 3.11+, aiogram 3, SQLite (aiosqlite), aiohttp, pydantic, python-dotenv, segno (QR).

## 1. Честно о состоянии проекта

| Что | Статус |
|---|---|
| Логика заказов, платежей, подписок, рефералов, промокодов, БД, миграции, бэкапы | Реализована и покрыта автотестами (68 тестов) |
| Адаптер 3X-UI | Реализован по документированным маршрутам, проверен на **имитации** панели. **На живой панели 3.11.0 не запускался** — выполните `python -m scripts.check_xui` (см. §6) |
| Telegram Stars / CryptoBot / DonateAlerts | Реализованы по документации API, проверены на заглушках. **Реальных платежей не проводилось** — сделайте тестовые платежи сами (§7) |
| Хендлеры aiogram, меню, админка | Написаны полностью; в среде разработки не было сети, поэтому **живой прогон с Telegram не выполнялся** — пройдите чек-лист §9 |
| `VPN_MODE=mock` | Выдаёт заглушки `flux-demo://NOT-A-REAL-CONFIG/...` (не рабочие конфигурации) |

Ограничения, о которых нужно знать:
* **DonateAlerts**: официальный API только *читает* список донатов (OAuth, `GET /api/v1/alerts/donations`); создавать счета и получать webhook'и нельзя. Поэтому оплата привязывается к заказу через **код `FX-XXXXXXXX` в сообщении доната**. Бот сопоставляет код + валюту RUB + сумму ≥ цены. Без OAuth — **ручное подтверждение админом** (скриншоты не принимаются).
* **Stars**: цены в Stars задаёт админ (Настройки → Тарифы → «⭐ Цена Stars»). Курс не выдумывается; пока цена не задана, Stars для тарифа недоступны.
* **3X-UI**: поддерживаются протоколы VLESS (REALITY/TLS/WS/gRPC…), VMess, Trojan, Shadowsocks. Hysteria/WireGuard и т.п. бот не выдаёт (будет понятная ошибка). Панели с включённой 2FA на логине не поддерживаются.
* **БД**: SQLite с одним соединением. Переход на PostgreSQL потребует заменить `database.py` (SQL написан переносимо, но плейсхолдеры `?` и `INSERT OR IGNORE`/`ON CONFLICT` нужно адаптировать).
* Кнопка «Копировать» (Telegram `copy_text`) ограничена 256 символами; для более длинных ссылок используйте нажатие на ссылку в `<code>`, QR-код или «Показать все ссылки».
* Цвета кнопок (синий/зелёный/красный) используются через поле `style`, **только если** установленный aiogram и клиент Telegram его поддерживают; иначе кнопки стандартные.
* Реальные платежи, коммерческий запуск, платёжные аккаунты и юридические вопросы настраивает взрослый ответственный владелец с соблюдением правил провайдеров и законов вашей юрисдикции.

## 2. Структура

```
bot.py config.py database.py        точка входа, конфиг (pydantic), БД/миграции/бэкапы
models/                             статусы и константы
handlers/                           start, menu, shop (+Stars), cabinet, connections, referrals, promo, support
admin/                              dashboard, statistics, users, payments, promos, settings, broadcasts
payments/                           base, telegram_stars, cryptobot, donatealerts, webhook
vpn/                                base, xui_adapter, mock_adapter, links, nodes, subscriptions
services/                           orders, subscriptions, users, plans, promo, referrals, notifications,
                                    fulfillment, scheduler, settings, container
keyboards/ middlewares/ utils/
migrations/0001_init.sql 0002_seed.sql
tests/  scripts/  deploy/
```

Ключевая гарантия: **единственная точка выдачи доступа за деньги — `Fulfillment.confirm()`** → `OrderService.apply_payment()`.
Одна транзакция: проверка заказа/провайдера/суммы → запись платежа с `UNIQUE(provider, external_id)` → заказ `PAID` → продление подписки → реферальный бонус. Повтор того же события ничего не меняет. VPN-панели обновляются **после** коммита; при сбое панели оплата сохраняется, подписка помечается `vpn_dirty`, повтор каждые 2 минуты, админ получает уведомление.

## 3. Установка на Ubuntu 22.04

```bash
sudo apt update && sudo apt install -y python3.11 python3.11-venv sqlite3 git   # если 3.11 нет: добавьте PPA deadsnakes
sudo adduser --system --group --home /opt/flux_vpn flux                         # НЕ root
sudo mkdir -p /opt/flux_vpn && sudo chown flux:flux /opt/flux_vpn
# скопируйте проект в /opt/flux_vpn (unzip flux_vpn.zip), затем:
sudo -u flux bash -c 'cd /opt/flux_vpn && python3.11 -m venv .venv && .venv/bin/pip install -U pip && .venv/bin/pip install -r requirements.txt'
sudo -u flux bash -c 'cd /opt/flux_vpn && cp .env.example .env && chmod 600 .env && mkdir -p data logs backups'
sudo -u flux nano /opt/flux_vpn/.env      # заполнить (см. ниже)
```

База создаётся и мигрируется автоматически при старте (перед миграциями на существующей БД делается копия в `backups/`).

Пробный запуск: `sudo -u flux bash -c 'cd /opt/flux_vpn && .venv/bin/python bot.py'`

### systemd (автозапуск и перезапуск при сбое)
```bash
sudo cp /opt/flux_vpn/deploy/flux-vpn.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now flux-vpn
sudo systemctl status flux-vpn
journalctl -u flux-vpn -f            # логи; также logs/flux.log (ротация, секреты маскируются)
```

### Резервные копии
* Бот сам делает копию каждые `BACKUP_INTERVAL_HOURS` и перед миграциями (хранится `BACKUP_KEEP`), кнопка «Резервная копия БД» в админке.
* Дополнительно: `deploy/flux-backup.cron` → `/etc/cron.d/flux-backup`. Копируйте `backups/` за пределы сервера.
* Восстановление: остановить бота → заменить `data/flux.db` нужной копией → запустить.

## 4. Настройка `.env`

Минимум: `BOT_TOKEN` (@BotFather), `ADMIN_IDS` (ваш Telegram ID), `SUPPORT_USERNAME`. Остальное — по разделам ниже.
Секреты хранятся только в `.env` (права 600) и маскируются в логах. Никогда не публикуйте `.env`.

## 5. Настройка 3X-UI (панель v3.11.0)

1. В каждой панели создайте inbound'ы (по 3 на страну): VLESS+REALITY, VLESS+TLS и др. Запомните их **ID в панели**.
2. Для Германии и США заполните блоки `XUI_DE_*` / `XUI_US_*`: `URL` (с `webBasePath`, без `/` на конце), `USERNAME`, `PASSWORD`, `HOST` (домен/IP для ссылок), `INBOUNDS` (ID через запятую). Если обе страны на одной панели — укажите одинаковый URL, но разные ID inbound'ов.
3. Создайте в панели отдельного пользователя для бота (не основной админ), если версия это позволяет.
4. `VPN_MODE=xui`, затем `cd /opt/flux_vpn && .venv/bin/python -m scripts.check_xui` — скрипт только читает панели и показывает протокол/порт каждого inbound.
5. Как работает выдача: для каждого пользователя и inbound создаётся клиент с email `flux<TG_ID>-<узел><N>`; дубликаты невозможны (поиск по email, `UNIQUE(user, inbound)`). Срок (`expiryTime`) ставится равным дате окончания, поэтому панель сама прекратит доступ, даже если бот лежит; при истечении бот дополнительно ставит `enable=false`.
6. Используемые маршруты: `POST /login`, `GET /panel/api/inbounds/get/:id`, `POST /panel/api/inbounds/addClient`, `POST /panel/api/inbounds/updateClient/:clientId`. После каждой записи бот перечитывает inbound и проверяет, что панель действительно применила изменения. Если на вашей версии маршруты/поля отличаются — правьте только `vpn/xui_adapter.py`.

## 6. Платёжные провайдеры

### ⭐ Telegram Stars
Ничего регистрировать не нужно. `STARS_ENABLED=true`. В админке: **Настройки → Тарифы → тариф → «⭐ Цена Stars»** — задайте цену для каждого тарифа. Используются `sendInvoice` (`currency=XTR`, без provider token), `pre_checkout_query` (проверка заказа, пользователя, суммы, срока), `successful_payment` (charge id сохраняется в `payments.external_id`), возврат — `refundStarPayment` (админка → заказ → «Вернуть Stars»; срок подписки уменьшается). Аварийный возврат: `/refund_stars <tg_id> <charge_id>`.

### 🪙 CryptoBot (Crypto Pay API)
1. @CryptoBot → *Crypto Pay* → *Create App* → скопируйте токен в `CRYPTOBOT_TOKEN`. Для тестов: @CryptoTestnetBot и `CRYPTOBOT_NETWORK=test`.
2. Счёт создаётся в **RUB** (`currency_type=fiat`), оплата — в активах из `CRYPTOBOT_ASSETS`.
3. Webhook: задайте `CRYPTOBOT_WEBHOOK_SECRET` (`openssl rand -hex 24`), поднимите nginx с HTTPS по `deploy/nginx-flux.conf`, в *Crypto Pay → My Apps → Webhooks* укажите `https://ваш-домен/webhooks/cryptobot/<CRYPTOBOT_WEBHOOK_SECRET>`.
   Подпись проверяется (HMAC-SHA256, ключ — SHA256 токена, заголовок `crypto-pay-api-signature`), сумма/валюта/ID сверяются с заказом. Без webhook работает опрос каждые 30 с и кнопка «Проверить оплату».

### 💳 DonateAlerts (DonationAlerts)
1. Укажите страницу донатов в `DONATEALERTS_URL`.
2. Автоподтверждение: создайте OAuth-приложение (https://www.donationalerts.com/application/clients), права `oauth-donation-index`, заполните `DONATEALERTS_CLIENT_ID/SECRET`, выполните `.venv/bin/python -m scripts.da_auth` (создаст файл токенов, обновляется автоматически).
3. Без OAuth — ручное подтверждение: пользователь жмёт «Я оплатил(а)», админ получает заявку с кнопками, сверяет поступление в кабинете DonationAlerts и подтверждает.
4. Платёж засчитывается только по донату с кодом заказа в сообщении, в RUB, на сумму ≥ цены. Один донат — один раз.
(Сверьтесь с актуальной официальной документацией DonationAlerts: эндпоинты OAuth/токенов могли измениться.)

## 7. Тесты

```bash
cd /opt/flux_vpn && .venv/bin/python -m unittest discover -s tests -t . -v
```
Тесты используют БД в памяти, фейковую панель 3X-UI, фейковые HTTP-клиенты и тестовые токены — реальные транзакции не проводятся.
Покрыто: регистрация, тарифы, заказы, Stars/CryptoBot/DonateAlerts, повторные уведомления, продление (с добавлением к дате окончания), истечение, промокоды, рефералы, права админа, ошибки 3X-UI (авторизация, сеть, отказ панели, «тихий» отказ записи, неподдерживаемый протокол), миграции и бэкап.

## 8. Админ-панель
`/admin` (только `ADMIN_IDS`): статистика; пользователи (поиск по ID, подписка, заказы, рефералы, блокировка, ручное продление при `ALLOW_MANUAL_EXTEND=true`); платежи (фильтры по провайдеру/статусу, поиск, ручное подтверждение DonateAlerts, возврат Stars); промокоды (создание/правка/отключение/удаление/статистика); рассылка (предпросмотр → подтверждение → отчёт, ≈20 сообщений/с, обработка блокировок и flood-лимитов); настройки (тарифы, цены Stars, бонус за реферала, статус интеграций, бэкап). Все действия пишутся в `admin_logs`.

## 9. Чек-лист первого запуска (сделайте до продажи!)
1. `VPN_MODE=mock`: пройти меню, промокод, реферал, кабинет — все кнопки.
2. `scripts.check_xui` → все 6 inbound «OK»; затем `VPN_MODE=xui`, выдать себе подписку промокодом и проверить, что 6 ссылок работают в клиенте.
3. Stars: задать цену, оплатить минимальный тариф, проверить выдачу, затем возврат из админки.
4. CryptoBot в testnet: оплата, webhook (и повторная доставка не продлевает дважды).
5. DonateAlerts: тестовый донат с кодом заказа / ручное подтверждение.
6. Дождаться (или сдвинуть время тестовой подпиской) уведомлений об окончании.

## 10. Бизнес-правила (решения по умолчанию)
* Реферальный бонус — **в днях**, на бонусный баланс, **только за первую подтверждённую покупку** приглашённого; по умолчанию 3 дня (меняется в админке). Реферал фиксируется только при первой регистрации; самоприглашение запрещено.
* Промокод — одноразовый на пользователя, с лимитом и сроком.
* Напоминания: за 3 суток, за сутки, за 6 часов («в день окончания») и при истечении; при простое бота отправляется только самое срочное.
* Неоплаченные заказы живут 60 мин (Stars/Crypto) и 180 мин (DonateAlerts), настраивается в `.env`. Платёж, пришедший по просроченному/отменённому заказу, всё равно засчитывается (деньги получены).
