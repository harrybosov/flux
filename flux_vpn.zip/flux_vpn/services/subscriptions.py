"""Подписки в БД. VPN-панель обновляется отдельно (vpn/subscriptions.py)."""
from __future__ import annotations

from models import SubStatus
from utils import clock

DAY = 86400


async def extend_tx(t, user_id: int, days: int, *, plan_id: str | None = None,
                    purchased: bool = False, now: int | None = None) -> dict:
    """Продлевает подписку. Активную — прибавляя к ТЕКУЩЕЙ дате окончания; истёкшую — от «сейчас»."""
    if days <= 0:
        raise ValueError("days must be > 0")
    now = now if now is not None else clock.now()
    row = await t.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
    add = days * DAY
    if row is None:
        await t.execute(
            "INSERT INTO subscriptions(user_id,plan_id,status,purchased_at,started_at,ends_at,vpn_dirty,updated_at)"
            " VALUES(?,?,?,?,?,?,1,?)",
            (user_id, plan_id, SubStatus.ACTIVE, now if purchased else None, now, now + add, now))
    else:
        active = row["status"] == SubStatus.ACTIVE and row["ends_at"] > now
        base = row["ends_at"] if active else now
        await t.execute(
            "UPDATE subscriptions SET plan_id=?, status=?, purchased_at=?, started_at=?, ends_at=?, "
            "vpn_dirty=1, updated_at=? WHERE id=?",
            (plan_id or row["plan_id"], SubStatus.ACTIVE, now if purchased else row["purchased_at"],
             row["started_at"] if active else now, base + add, now, row["id"]))
    return await t.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))


async def shorten_tx(t, user_id: int, days: int, now: int | None = None) -> dict | None:
    """Уменьшает срок (возврат платежа). Не уходит в прошлое дальше «сейчас»."""
    now = now if now is not None else clock.now()
    row = await t.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
    if row is None:
        return None
    new_end = row["ends_at"] - days * DAY
    if new_end <= now:
        await t.execute("UPDATE subscriptions SET status=?, ends_at=?, vpn_dirty=1, updated_at=? WHERE id=?",
                        (SubStatus.EXPIRED, min(row["ends_at"], now), now, row["id"]))
    else:
        await t.execute("UPDATE subscriptions SET ends_at=?, vpn_dirty=1, updated_at=? WHERE id=?",
                        (new_end, now, row["id"]))
    return await t.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))


class SubscriptionService:
    def __init__(self, db):
        self.db = db

    async def get(self, user_id: int) -> dict | None:
        return await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))

    async def view(self, user_id: int) -> dict | None:
        """Подписка + вычисленные поля remaining / is_active."""
        sub = await self.get(user_id)
        if not sub:
            return None
        now = clock.now()
        sub["remaining"] = max(0, sub["ends_at"] - now)
        sub["is_active"] = sub["status"] == SubStatus.ACTIVE and sub["ends_at"] > now
        return sub

    async def extend(self, user_id: int, days: int, *, plan_id: str | None = None) -> dict:
        async with self.db.tx() as t:
            return await extend_tx(t, user_id, days, plan_id=plan_id)

    async def due_for_expiry(self, now: int | None = None) -> list[dict]:
        now = now if now is not None else clock.now()
        return await self.db.fetchall(
            "SELECT * FROM subscriptions WHERE status=? AND ends_at<=?", (SubStatus.ACTIVE, now))

    async def mark_expired(self, sub_id: int, now: int | None = None) -> bool:
        now = now if now is not None else clock.now()
        n = await self.db.execute(
            "UPDATE subscriptions SET status=?, vpn_dirty=1, updated_at=? "
            "WHERE id=? AND status=? AND ends_at<=?", (SubStatus.EXPIRED, now, sub_id, SubStatus.ACTIVE, now))
        return n > 0

    async def expiring_within(self, seconds: int, now: int | None = None) -> list[dict]:
        now = now if now is not None else clock.now()
        return await self.db.fetchall(
            "SELECT * FROM subscriptions WHERE status=? AND ends_at>? AND ends_at<=?",
            (SubStatus.ACTIVE, now, now + seconds))

    async def dirty(self, limit: int = 50) -> list[dict]:
        return await self.db.fetchall(
            "SELECT * FROM subscriptions WHERE vpn_dirty=1 ORDER BY updated_at LIMIT ?", (limit,))
