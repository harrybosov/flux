"""Заказы и идемпотентная обработка оплат."""
from __future__ import annotations

import secrets
import sqlite3
from dataclasses import dataclass, field

from models import CURRENCY_RUB, CURRENCY_STARS, OrderStatus, PaymentStatus, Provider
from services import referrals
from services.subscriptions import extend_tx, shorten_tx
from utils import clock


class OrderError(Exception):
    """Сообщение пригодно для показа пользователю."""


@dataclass
class PaymentOutcome:
    status: str                      # ok | duplicate | rejected | already_paid | not_found
    order: dict | None = None
    subscription: dict | None = None
    reward: dict | None = None       # {"referrer": user_row, "bonus_days": n}
    was_active_before: bool = False
    reason: str = ""


class OrderService:
    def __init__(self, db, plans, ttl_minutes: dict[str, int] | None = None):
        self.db = db
        self.plans = plans
        self.ttl = ttl_minutes or {Provider.STARS: 60, Provider.CRYPTOBOT: 60, Provider.DONATEALERTS: 180}

    # ---------- создание ----------
    async def create_order(self, user_id: int, plan_id: str, provider: str) -> dict:
        if provider not in Provider.ORDER_PROVIDERS:
            raise OrderError("Неизвестный способ оплаты")
        plan = await self.plans.get(plan_id)
        if not plan or not plan["is_active"]:
            raise OrderError("Тариф недоступен")
        if provider == Provider.STARS:
            amount, currency = await self.plans.stars_price(plan_id), CURRENCY_STARS
            if not amount:
                raise OrderError("Цена в Stars для этого тарифа ещё не задана")
        else:
            amount, currency = plan["price_rub"], CURRENCY_RUB
        now = clock.now()
        async with self.db.tx() as t:
            existing = await t.fetchone(
                "SELECT * FROM orders WHERE user_id=? AND plan_id=? AND provider=? AND status=? "
                "AND expires_at>? AND amount=? ORDER BY id DESC LIMIT 1",
                (user_id, plan_id, provider, OrderStatus.PENDING, now, amount))
            if existing:
                return existing
            public_id = "FX-" + secrets.token_hex(4).upper()
            oid = await t.insert(
                "INSERT INTO orders(public_id,user_id,plan_id,plan_name,days,provider,amount,currency,status,"
                "created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (public_id, user_id, plan_id, plan["name"], plan["days"], provider, amount, currency,
                 OrderStatus.PENDING, now, now + self.ttl.get(provider, 60) * 60))
            return await t.fetchone("SELECT * FROM orders WHERE id=?", (oid,))

    async def set_external(self, order_id: int, external_id: str | None, pay_url: str | None) -> None:
        await self.db.execute("UPDATE orders SET external_id=COALESCE(?, external_id), pay_url=COALESCE(?, pay_url) "
                              "WHERE id=?", (external_id, pay_url, order_id))

    # ---------- чтение ----------
    async def get(self, order_id: int) -> dict | None:
        return await self.db.fetchone("SELECT * FROM orders WHERE id=?", (order_id,))

    async def get_by_public(self, public_id: str) -> dict | None:
        return await self.db.fetchone("SELECT * FROM orders WHERE public_id=?", ((public_id or "").upper(),))

    async def get_by_external(self, provider: str, external_id: str) -> dict | None:
        return await self.db.fetchone(
            "SELECT * FROM orders WHERE provider=? AND external_id=?", (provider, str(external_id)))

    async def list_for_user(self, user_id: int, limit: int = 10) -> list[dict]:
        return await self.db.fetchall(
            "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))

    async def list_filtered(self, provider: str | None, status: str | None,
                            limit: int = 8, offset: int = 0) -> list[dict]:
        where, params = [], []
        if provider:
            where.append("o.provider=?"); params.append(provider)
        if status:
            where.append("o.status=?"); params.append(status)
        sql = ("SELECT o.*, u.tg_id FROM orders o JOIN users u ON u.id=o.user_id"
               + (" WHERE " + " AND ".join(where) if where else "")
               + " ORDER BY o.id DESC LIMIT ? OFFSET ?")
        return await self.db.fetchall(sql, (*params, limit, offset))

    async def pending_by_provider(self, provider: str) -> list[dict]:
        return await self.db.fetchall(
            "SELECT * FROM orders WHERE provider=? AND status=? AND expires_at>?",
            (provider, OrderStatus.PENDING, clock.now()))

    # ---------- переходы статусов ----------
    async def cancel(self, order_id: int, user_id: int | None = None) -> bool:
        sql = "UPDATE orders SET status=? WHERE id=? AND status=?"
        params: list = [OrderStatus.CANCELLED, order_id, OrderStatus.PENDING]
        if user_id is not None:
            sql += " AND user_id=?"
            params.append(user_id)
        return (await self.db.execute(sql, params)) > 0

    async def expire_stale(self, now: int | None = None) -> int:
        now = now if now is not None else clock.now()
        return await self.db.execute(
            "UPDATE orders SET status=? WHERE status=? AND expires_at<=?",
            (OrderStatus.EXPIRED, OrderStatus.PENDING, now))

    # ---------- ГЛАВНОЕ: идемпотентное подтверждение оплаты ----------
    async def apply_payment(self, order_id: int, *, source: str, external_id: str, amount: int,
                            currency: str, note: str | None = None) -> PaymentOutcome:
        """Одна транзакция: проверка заказа → запись платежа (UNIQUE) → заказ PAID → подписка → реферал.
        Повторный вызов с тем же (source, external_id) ничего не меняет (status='duplicate')."""
        now = clock.now()
        external_id = str(external_id)
        async with self.db.tx() as t:
            order = await t.fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
            if not order:
                return PaymentOutcome("not_found", reason="order not found")
            dup = await t.fetchone("SELECT 1 FROM payments WHERE provider=? AND external_id=?",
                                   (source, external_id))
            if dup:
                return PaymentOutcome("duplicate", order=order)
            if source != Provider.MANUAL and source != order["provider"]:
                return await self._reject(t, order, source, external_id, amount, currency, now,
                                          "provider mismatch")
            if currency != order["currency"] or amount < order["amount"]:
                return await self._reject(t, order, source, external_id, amount, currency, now,
                                          f"amount mismatch: got {amount} {currency}, "
                                          f"expected {order['amount']} {order['currency']}")
            if order["status"] in (OrderStatus.PAID, OrderStatus.REFUNDED):
                return await self._reject(t, order, source, external_id, amount, currency, now,
                                          "order already " + order["status"].lower())
            # платёж реально получен → принимаем даже если заказ был EXPIRED/CANCELLED
            try:
                await t.insert(
                    "INSERT INTO payments(order_id,provider,external_id,amount,currency,status,note,created_at)"
                    " VALUES(?,?,?,?,?,?,?,?)",
                    (order["id"], source, external_id, amount, currency, PaymentStatus.PAID, note, now))
            except sqlite3.IntegrityError:
                return PaymentOutcome("duplicate", order=order)
            n = await t.execute(
                "UPDATE orders SET status=?, paid_at=?, external_id=COALESCE(external_id, ?) "
                "WHERE id=? AND status IN (?,?,?)",
                (OrderStatus.PAID, now, external_id, order["id"],
                 OrderStatus.PENDING, OrderStatus.EXPIRED, OrderStatus.CANCELLED))
            if n == 0:
                raise RuntimeError("order status changed concurrently")
            before = await t.fetchone("SELECT status, ends_at FROM subscriptions WHERE user_id=?",
                                      (order["user_id"],))
            was_active = bool(before and before["status"] == "ACTIVE" and before["ends_at"] > now)
            sub = await extend_tx(t, order["user_id"], order["days"], plan_id=order["plan_id"],
                                  purchased=True, now=now)
            reward = await referrals.reward_tx(t, order, now)
            order = await t.fetchone("SELECT * FROM orders WHERE id=?", (order["id"],))
        return PaymentOutcome("ok", order=order, subscription=sub, reward=reward, was_active_before=was_active)

    async def _reject(self, t, order, source, external_id, amount, currency, now, reason) -> PaymentOutcome:
        try:
            await t.insert(
                "INSERT INTO payments(order_id,provider,external_id,amount,currency,status,note,created_at)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (order["id"], source, external_id, amount, currency, PaymentStatus.REJECTED, reason, now))
        except sqlite3.IntegrityError:
            return PaymentOutcome("duplicate", order=order)
        status = "already_paid" if reason.startswith("order already") else "rejected"
        return PaymentOutcome(status, order=order, reason=reason)

    # ---------- возврат ----------
    async def apply_refund(self, order_id: int) -> PaymentOutcome:
        """Помечает заказ REFUNDED и уменьшает срок подписки на срок заказа."""
        now = clock.now()
        async with self.db.tx() as t:
            order = await t.fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
            if not order or order["status"] != OrderStatus.PAID:
                return PaymentOutcome("rejected", order=order, reason="order is not PAID")
            await t.execute("UPDATE orders SET status=? WHERE id=?", (OrderStatus.REFUNDED, order_id))
            await t.execute("UPDATE payments SET status=? WHERE order_id=? AND status=?",
                            (PaymentStatus.REFUNDED, order_id, PaymentStatus.PAID))
            sub = await shorten_tx(t, order["user_id"], order["days"], now)
            order = await t.fetchone("SELECT * FROM orders WHERE id=?", (order_id,))
        return PaymentOutcome("ok", order=order, subscription=sub)

    async def payment_for_order(self, order_id: int) -> dict | None:
        return await self.db.fetchone(
            "SELECT * FROM payments WHERE order_id=? AND status IN ('PAID','REFUNDED') ORDER BY id LIMIT 1",
            (order_id,))
