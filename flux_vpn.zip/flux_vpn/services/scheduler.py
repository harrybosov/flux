"""Фоновые задачи: истечение подписок, напоминания, повтор синхронизации VPN, опрос платежей, бэкапы."""
from __future__ import annotations

import asyncio
import logging

from utils import clock, texts

log = logging.getLogger(__name__)

H = 3600
REMINDERS = [("EXPIRE_3D", 72 * H), ("EXPIRE_1D", 24 * H), ("EXPIRE_TODAY", 6 * H)]  # от менее срочного к более


class Scheduler:
    def __init__(self, db, orders, subs, vpn, notifier, users, providers, tz, backup_dir,
                 backup_keep, backup_interval_hours):
        self.db, self.orders, self.subs, self.vpn = db, orders, subs, vpn
        self.notifier, self.users, self.providers, self.tz = notifier, users, providers, tz
        self.backup_dir, self.backup_keep = backup_dir, backup_keep
        self.backup_interval = backup_interval_hours * H
        self._tasks: list[asyncio.Task] = []

    def start(self) -> None:
        self._tasks = [
            asyncio.create_task(self._loop("subscriptions", 60, self.tick_subscriptions)),
            asyncio.create_task(self._loop("vpn-retry", 120, self.retry_vpn)),
            asyncio.create_task(self._loop("orders", 30, self.tick_orders)),
        ]
        if self.backup_interval > 0:
            self._tasks.append(asyncio.create_task(self._loop("backup", self.backup_interval, self.backup, first=False)))

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)

    async def _loop(self, name: str, interval: float, fn, first: bool = True) -> None:
        if not first:
            await asyncio.sleep(interval)
        while True:
            try:
                await fn()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("scheduler job %s failed", name)
            await asyncio.sleep(interval)

    async def tick_orders(self) -> None:
        await self.orders.expire_stale()
        for p in self.providers.values():
            await p.poll_pending()

    async def tick_subscriptions(self) -> None:
        now = clock.now()
        # 1) истёкшие: статус → EXPIRED, отключить клиентов, уведомить
        for sub in await self.subs.due_for_expiry(now):
            if await self.subs.mark_expired(sub["id"], now):
                await self.vpn.sync_user(sub["user_id"])
                user = await self.users.get(sub["user_id"])
                await self.notifier.once(user, "EXPIRED", str(sub["ends_at"]), texts.n_expire("EXPIRED", ""))
        # 2) напоминания: берём самое срочное из применимых, остальные помечаем отправленными молча
        for sub in await self.subs.expiring_within(72 * H, now):
            remaining = sub["ends_at"] - now
            applicable = [k for k, lim in REMINDERS if remaining <= lim]
            if not applicable:
                continue
            ref = str(sub["ends_at"])
            user = await self.users.get(sub["user_id"])
            for k in applicable[:-1]:
                await self.notifier.mark_only(user["id"], k, ref)
            await self.notifier.once(user, applicable[-1], ref,
                                     texts.n_expire(applicable[-1], texts.fmt_dt(sub["ends_at"], self.tz)))

    async def retry_vpn(self) -> None:
        for sub in await self.subs.dirty(limit=30):
            res = await self.vpn.sync_user(sub["user_id"])
            if res.ok:
                user = await self.users.get(sub["user_id"])
                active = sub["status"] == "ACTIVE" and sub["ends_at"] > clock.now()
                if active and sub.get("vpn_error"):
                    await self.notifier.once(user, "VPN_READY", str(sub["ends_at"]), texts.n_vpn_ready())

    async def backup(self) -> None:
        await self.db.backup(self.backup_dir, keep=self.backup_keep)
