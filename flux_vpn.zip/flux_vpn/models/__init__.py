"""Перечисления и константы предметной области."""


class OrderStatus:
    PENDING = "PENDING"
    PAID = "PAID"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"
    REFUNDED = "REFUNDED"
    ALL = (PENDING, PAID, EXPIRED, CANCELLED, REFUNDED)


class Provider:
    STARS = "STARS"
    CRYPTOBOT = "CRYPTOBOT"
    DONATEALERTS = "DONATEALERTS"
    MANUAL = "MANUAL"  # только как источник платежа (подтверждение админом)
    ORDER_PROVIDERS = (STARS, CRYPTOBOT, DONATEALERTS)


class SubStatus:
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"


class PaymentStatus:
    PAID = "PAID"
    REFUNDED = "REFUNDED"
    REJECTED = "REJECTED"


CURRENCY_RUB = "RUB"
CURRENCY_STARS = "XTR"

PROVIDER_TITLES = {
    Provider.STARS: "⭐ Telegram Stars",
    Provider.CRYPTOBOT: "🪙 CryptoBot",
    Provider.DONATEALERTS: "💳 DonateAlerts",
    Provider.MANUAL: "Ручное подтверждение",
}
